// sub-buyer/pages/order-detail/order-detail.js —— 订单详情
//
// 职责：
//   status=2 展示 3 张发货照片 + 确认/驳回（调 confirmShipment）
//   status=3 展示确认收货按钮（调 confirmReceipt）
//   status=3/4 提供发起售后入口（跳 return-apply）
//   status=5 展示系统判定结论，liable=true 时给「去处理售后」入口
//   status=4 且售后未通过时展示「售后未通过」与理由
//
// 所有状态比较在 JS 里算成布尔量，WXML 只做展示（CLAUDE.md 前端规范）。
const { formatTime, formatPrice } = require('../../../utils/format')
const { toDate, toDisplayUrls } = require('../../utils/display')
const { formatRegion } = require('../../utils/address')
const { ORDER_STATUS, ORDER_STATUS_TEXT, ORDER_STATUS_THEME } = require('../../../utils/constant')

const REASON_MAX_LEN = 100

Page({
  data: {
    orderId: '',
    order: null,
    items: [],
    shipPhotos: [],   // 已换成 <image> 可用的地址
    returnPhotos: [],
    statusText: '',
    statusTheme: '',
    totalPriceText: '',
    addressText: '',
    addressName: '',
    addressPhone: '',
    createTimeText: '',
    receiveAtText: '',
    refundAtText: '',
    reshipCount: 0,
    shipRejectReason: '',
    hasReturn: false,
    liable: null,
    judgeReason: '',
    showReturnRejected: false,

    // 按状态预计算的布尔量
    canConfirmShip: false,
    canConfirmReceipt: false,
    canApplyReturn: false,
    canResolveReturn: false,
    hasActions: false,

    // 驳回原因输入弹层
    rejecting: false,
    rejectReason: '',

    loading: true,
    submitting: false,
    error: ''
  },

  onLoad(options) {
    const orderId = options && options.id
    if (!orderId) {
      this.setData({ loading: false, error: '缺少订单参数' })
      return
    }
    this.setData({ orderId })
  },

  onShow() {
    // 从售后申请页返回时状态可能已变化，这里重新拉一次
    if (this.data.orderId) {
      this.loadOrder()
    }
  },

  loadOrder() {
    this.setData({ loading: true, error: '' })

    wx.cloud.callFunction({
      name: 'getMyOrders',
      data: { orderId: this.data.orderId },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          this.setData({ loading: false, error: result.msg || '加载失败' })
          return
        }
        this.applyOrder(result.order || {})
      },
      fail: (err) => {
        console.error('[FreshBuy] 读取订单详情失败', err)
        this.setData({ loading: false, error: '网络异常，请稍后重试' })
      }
    })
  },

  /** 把订单数据整理成 WXML 直接可用的形态 */
  applyOrder(order) {
    const status = Number(order.status)
    const ret = order.return || {}
    const addr = order.address || {}

    const items = (order.items || []).map((item) => ({
      ...item,
      priceText: formatPrice(item.price),
      subtotalText: formatPrice(Number(item.price) * Number(item.count))
    }))

    // 商家端展示与买家端一致：省 + 市 + 区 + 详细地址。
    // 用 formatRegion 而非直接拼接：直辖市的省与市同名（'北京市' + '北京市'），
    // 直接连起来会显示成「北京市北京市朝阳区」。
    const addressText = [formatRegion(addr.province, addr.city, addr.district), addr.detail]
      .filter(Boolean)
      .join('')

    const canConfirmShip = status === ORDER_STATUS.PENDING_CONFIRM_SHIP
    const canConfirmReceipt = status === ORDER_STATUS.DELIVERING
    // 售后一经判定为非商家责任即为终局，不再提供重复申请入口
    // （与 applyReturn 云函数内的拦截保持一致，避免用户点了才被拒）
    const canApplyReturn =
      (status === ORDER_STATUS.DELIVERING || status === ORDER_STATUS.FINISHED) &&
      ret.resolution !== 'rejected'
    const canResolveReturn =
      status === ORDER_STATUS.AFTER_SALE && ret.liable === true

    this.setData({
      order,
      items,
      statusText: ORDER_STATUS_TEXT[status] || '未知',
      statusTheme: ORDER_STATUS_THEME[status] || 'done',
      totalPriceText: formatPrice(order.totalPrice),
      addressText: addressText || '（未记录收货地址）',
      addressName: addr.name || '',
      addressPhone: addr.phone || '',
      createTimeText: formatTime(toDate(order.createTime)),
      receiveAtText: formatTime(toDate(order.receiveAt)),
      refundAtText: formatTime(toDate(ret.refundAt)),
      reshipCount: Number(order.reshipCount) || 0,
      shipRejectReason: order.shipRejectReason || '',
      hasReturn: !!order.return,
      liable: typeof ret.liable === 'boolean' ? ret.liable : null,
      judgeReason: ret.reason || '',
      // 售后未通过：系统判定非商家责任，订单已自动回退到 4 并写入 rejected
      showReturnRejected: ret.liable === false && ret.resolution === 'rejected',
      canConfirmShip,
      canConfirmReceipt,
      canApplyReturn,
      canResolveReturn,
      hasActions: canConfirmShip || canConfirmReceipt || canApplyReturn || canResolveReturn,
      loading: false
    })

    this.loadPhotos(order, ret)
  },

  /** 照片存的是 fileID，展示前需要换临时链接（占位图会原样透传） */
  loadPhotos(order, ret) {
    toDisplayUrls(order.shipPhotos).then((list) => {
      this.setData({ shipPhotos: list })
    })
    toDisplayUrls(ret.photos).then((list) => {
      this.setData({ returnPhotos: list })
    })
  },

  /** 预览照片 */
  onPreviewShipPhoto(e) {
    const index = Number(e.currentTarget.dataset.index) || 0
    wx.previewImage({ current: this.data.shipPhotos[index], urls: this.data.shipPhotos })
  },

  onPreviewReturnPhoto(e) {
    const index = Number(e.currentTarget.dataset.index) || 0
    wx.previewImage({ current: this.data.returnPhotos[index], urls: this.data.returnPhotos })
  },

  // ---------------- 发货照片确认 / 驳回 ----------------

  /** 确认无误：2 -> 3 */
  onConfirmShip() {
    this.callConfirmShipment(true, '')
  },

  /** 打开驳回原因输入弹层 */
  onRejectShip() {
    this.setData({ rejecting: true, rejectReason: '' })
  },

  onRejectInput(e) {
    this.setData({ rejectReason: e.detail.value })
  },

  onRejectCancel() {
    this.setData({ rejecting: false, rejectReason: '' })
  },

  onRejectConfirm() {
    const reason = String(this.data.rejectReason || '').trim()
    if (!reason) {
      wx.showToast({ title: '请填写驳回原因', icon: 'none' })
      return
    }
    this.setData({ rejecting: false })
    this.callConfirmShipment(false, reason)
  },

  callConfirmShipment(pass, reason) {
    if (this.data.submitting) return
    this.setData({ submitting: true })
    wx.showLoading({ title: '处理中…', mask: true })

    wx.cloud.callFunction({
      name: 'confirmShipment',
      data: { orderId: this.data.orderId, pass, reason },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '操作失败', icon: 'none' })
          return
        }
        wx.showToast({ title: pass ? '已确认' : '已驳回', icon: 'success' })
        this.loadOrder()
      },
      fail: (err) => {
        console.error('[FreshBuy] 确认发货照片失败', err)
        wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
      },
      complete: () => {
        wx.hideLoading()
        this.setData({ submitting: false })
      }
    })
  },

  // ---------------- 确认收货 ----------------

  onConfirmReceipt() {
    wx.showModal({
      title: '确认收货',
      content: '确认已收到商品？确认后订单将变为已完成。',
      success: (res) => {
        if (res.confirm) this.callConfirmReceipt()
      }
    })
  },

  callConfirmReceipt() {
    if (this.data.submitting) return
    this.setData({ submitting: true })
    wx.showLoading({ title: '处理中…', mask: true })

    wx.cloud.callFunction({
      name: 'confirmReceipt',
      data: { orderId: this.data.orderId },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '操作失败', icon: 'none' })
          return
        }
        wx.showToast({ title: '已确认收货', icon: 'success' })
        this.loadOrder()
      },
      fail: (err) => {
        console.error('[FreshBuy] 确认收货失败', err)
        wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
      },
      complete: () => {
        wx.hideLoading()
        this.setData({ submitting: false })
      }
    })
  },

  // ---------------- 售后入口 ----------------

  /** 发起售后 / 处理售后结果，都走同一个页面，由它按订单状态决定展示什么 */
  onApplyReturn() {
    wx.navigateTo({
      url: `/sub-buyer/pages/return-apply/return-apply?orderId=${this.data.orderId}`
    })
  }
})
