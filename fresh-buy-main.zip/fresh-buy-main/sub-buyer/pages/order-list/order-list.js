// sub-buyer/pages/order-list/order-list.js —— 我的订单
//
// 列表由 getMyOrders 云函数返回（云函数内用 getWXContext() 的 OPENID 过滤），
// 保证只看到自己的订单，同时无需放开 orders 集合的读权限。
// 注意：tab 中不含「待支付」—— 本项目无支付环节，下单即进入「待发货」。
const { formatTime, formatPrice } = require('../../../utils/format')
const { toDate } = require('../../utils/display')
const { ORDER_STATUS, ORDER_STATUS_TEXT, ORDER_STATUS_THEME } = require('../../../utils/constant')

const PAGE_SIZE = 10

Page({
  data: {
    // -1 表示「全部」：WXML 的 dataset 会把 null 转成空字符串，
    // 直接用 null 会退化成 where({ status: '' }) 而查不到数据
    tabs: [
      { status: -1, name: '全部' },
      { status: ORDER_STATUS.PENDING_SHIP, name: ORDER_STATUS_TEXT[ORDER_STATUS.PENDING_SHIP] },
      {
        status: ORDER_STATUS.PENDING_CONFIRM_SHIP,
        name: ORDER_STATUS_TEXT[ORDER_STATUS.PENDING_CONFIRM_SHIP]
      },
      { status: ORDER_STATUS.DELIVERING, name: ORDER_STATUS_TEXT[ORDER_STATUS.DELIVERING] },
      { status: ORDER_STATUS.FINISHED, name: ORDER_STATUS_TEXT[ORDER_STATUS.FINISHED] },
      { status: ORDER_STATUS.AFTER_SALE, name: ORDER_STATUS_TEXT[ORDER_STATUS.AFTER_SALE] },
      { status: ORDER_STATUS.CLOSED, name: ORDER_STATUS_TEXT[ORDER_STATUS.CLOSED] }
    ],
    activeStatus: -1,
    orders: [],
    page: 1,
    hasMore: true,
    loading: false,
    refreshing: false,
    // 空态文案要分「一单没有」与「该状态下没单」两种，否则筛完看不懂
    emptyIcon: '📋',
    emptyText: '还没有任何订单',
    error: ''
  },

  onShow() {
    // 每次进入都重新拉取：从订单详情页返回时状态可能已经变了
    this.refreshEmptyText()
    this.loadOrders(true)
  },

  /** 按当前筛选状态更新空态文案 */
  refreshEmptyText() {
    const status = this.data.activeStatus

    if (status === -1) {
      this.setData({ emptyIcon: '📋', emptyText: '还没有任何订单' })
      return
    }

    const tab = this.data.tabs.filter((item) => item.status === status)[0]
    this.setData({
      emptyIcon: '🔍',
      emptyText: `暂无「${(tab && tab.name) || '该状态'}」的订单`
    })
  },

  onPullDownRefresh() {
    this.setData({ refreshing: true })
    this.loadOrders(true, () => {
      this.setData({ refreshing: false })
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadOrders(false)
    }
  },

  /** 切换状态筛选 */
  onTabTap(e) {
    const status = e.currentTarget.dataset.status
    if (status === this.data.activeStatus) return
    this.setData({ activeStatus: status, orders: [], hasMore: true })
    this.refreshEmptyText()
    this.loadOrders(true)
  },

  /**
   * 分页加载订单
   * @param {boolean} reset true 表示重置到第一页
   * @param {Function} done 加载结束回调
   */
  loadOrders(reset, done) {
    const page = reset ? 1 : this.data.page + 1
    this.setData({ loading: true, error: '' })

    wx.cloud.callFunction({
      name: 'getMyOrders',
      data: {
        status: this.data.activeStatus,
        page,
        pageSize: PAGE_SIZE
      },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          this.setData({ loading: false, error: result.msg || '加载失败' })
          return
        }

        const list = (result.list || []).map((order) => this.decorateOrder(order))

        this.setData({
          orders: reset ? list : this.data.orders.concat(list),
          page,
          hasMore: !!result.hasMore,
          loading: false
        })
      },
      fail: (err) => {
        console.error('[FreshBuy] 获取我的订单失败', err)
        this.setData({ loading: false, error: '网络异常，请稍后重试' })
      },
      complete: () => {
        if (typeof done === 'function') done()
      }
    })
  },

  /** 补齐 WXML 需要的展示字段，避免在模板里做运算与判空 */
  decorateOrder(order) {
    const items = order.items || []

    return {
      ...order,
      totalPriceText: formatPrice(order.totalPrice),
      // 云函数返回的时间是 ISO 字符串，必须先经 toDate 归一化（见 display.js 注释）
      createTimeText: formatTime(toDate(order.createTime)),
      statusText: ORDER_STATUS_TEXT[order.status] || '未知',
      statusTheme: ORDER_STATUS_THEME[order.status] || 'done',
      count: items.reduce((sum, i) => sum + Number(i.count || 0), 0),
      summary: items.length
        ? `${items[0].name}${items.length > 1 ? ` 等 ${items.length} 种商品` : ''}`
        : '商品信息缺失',
      isReship: Number(order.reshipCount) > 0
    }
  },

  /** 查看订单详情 */
  onOrderTap(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/sub-buyer/pages/order-detail/order-detail?id=${id}` })
  },

  /** 去逛逛 */
  onGoHome() {
    wx.navigateTo({
      url: '/sub-buyer/pages/home/home',
      fail: () => wx.redirectTo({ url: '/sub-buyer/pages/home/home' })
    })
  }
})
