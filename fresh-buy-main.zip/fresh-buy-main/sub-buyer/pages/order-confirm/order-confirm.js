// sub-buyer/pages/order-confirm/order-confirm.js —— 确认下单
//
// 职责：收货地址表单（微信地址预填 / 剪贴板粘贴 / 手改）+ 商品清单 + 提交。
// 提交调 createOrder 云函数，入参 { items, address }；address 由云函数按快照写入订单。
//
// 两种入口（用 mode 区分）：
//   mode=detail&productId=x&count=n  从商品详情页「立即购买」进来
//   mode=cart                        从购物车「结算」进来，下单成功后清空已下单条目
const { formatPrice, calcTotal } = require('../../../utils/format')
const { parseAddressText, formatRegion } = require('../../utils/address')

const db = wx.cloud.database()

/** 地址结构固定为 { name, phone, province, city, district, detail, postalCode }，见 CLAUDE.md */
const EMPTY_ADDRESS = {
  name: '',
  phone: '',
  province: '',
  city: '',
  district: '',
  detail: '',
  postalCode: ''
}

const EMPTY_ERRORS = { name: '', phone: '', region: '', detail: '' }

/**
 * picker mode="region" 的 value 必须是合法的三元数组。
 * 传空数组或不存在的省市区会让滚轮定位异常，所以没有完整选择时回落到默认值。
 */
const DEFAULT_REGION = ['广东省', '广州市', '海珠区']

/** 由 address 的省市区推出 picker 需要的 value */
function toRegionValue(province, city, district) {
  const p = String(province || '').trim()
  const c = String(city || '').trim()
  const d = String(district || '').trim()
  return (p && c && d) ? [p, c, d] : DEFAULT_REGION.slice()
}

Page({
  data: {
    mode: '',
    items: [],
    totalCount: 0,
    totalText: '0.00',
    address: { ...EMPTY_ADDRESS },
    regionValue: DEFAULT_REGION.slice(),
    regionText: '',
    errors: { ...EMPTY_ERRORS },
    cartIds: [], // 来自购物车时记录条目 id，下单成功后据此清空
    loading: true,
    submitting: false,
    error: ''
  },

  onLoad(options) {
    const opts = options || {}
    this.setData({ mode: opts.mode === 'cart' ? 'cart' : 'detail' })
    this.prefillAddress()
    this.loadItems(opts)
  },

  /** 地址预填：login 云函数返回的 userInfo 里带着上次下单记住的地址 */
  prefillAddress() {
    const app = getApp()
    const saved = app.globalData.userInfo && app.globalData.userInfo.address
    if (!saved) return

    this.setData({
      address: {
        name: saved.name || '',
        phone: saved.phone || '',
        province: saved.province || '',
        city: saved.city || '',
        district: saved.district || '',
        detail: saved.detail || '',
        postalCode: saved.postalCode || ''
      }
    })
    this.refreshRegion()
  },

  /** 由 address 的省市区重算 picker 的 value 与展示文案 */
  refreshRegion() {
    const a = this.data.address
    this.setData({
      regionValue: toRegionValue(a.province, a.city, a.district),
      // 直辖市省与市同名，用 formatRegion 去重，否则会显示成「北京市北京市朝阳区」
      regionText: formatRegion(a.province, a.city, a.district)
    })
  },

  loadItems(opts) {
    if (this.data.mode === 'cart') {
      this.loadFromCart(opts.cartIds)
    } else {
      this.loadFromProduct(opts.productId, opts.count)
    }
  },

  /** 来源一：单个商品直接购买 */
  loadFromProduct(productId, count) {
    if (!productId) {
      this.setData({ loading: false, error: '缺少商品参数' })
      return
    }

    const buyCount = Math.max(Math.floor(Number(count)) || 1, 1)

    // 读操作允许前端直查（CLAUDE.md 只约束写操作必须经云函数）
    db.collection('products')
      .doc(productId)
      .get()
      .then((res) => {
        const product = res.data
        this.setData({ loading: false })
        this.setItems([
          {
            productId: product._id,
            name: product.name,
            price: Number(product.price),
            count: buyCount,
            image: (product.images && product.images[0]) || ''
          }
        ])
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取商品失败', err)
        this.setData({ loading: false, error: '商品不存在或已被下架' })
      })
  },

  /** 来源二：购物车结算。传了 cartIds 只结算选中条目，未传则结算整车 */
  loadFromCart(cartIdsParam) {
    const app = getApp()
    const openid = app.globalData.openid

    if (!openid) {
      this.setData({ loading: false, error: '未获取到登录信息，请返回首页重新登录' })
      return
    }

    const picked = String(cartIdsParam || '')
      .split(',')
      .map((id) => id.trim())
      .filter(Boolean)

    db.collection('cart')
      .where({ userId: openid })
      .get()
      .then((res) => {
        let list = res.data || []
        if (picked.length) {
          list = list.filter((item) => picked.indexOf(item._id) !== -1)
        }

        if (list.length === 0) {
          this.setData({ loading: false, error: '没有可结算的商品' })
          return
        }

        this.setData({
          loading: false,
          cartIds: list.map((item) => item._id)
        })

        this.setItems(
          list.map((item) => ({
            productId: item.productId,
            name: item.name,
            price: Number(item.price),
            count: Number(item.count) || 1,
            image: item.image || ''
          }))
        )
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取购物车失败', err)
        this.setData({ loading: false, error: '加载失败，请稍后重试' })
      })
  },

  /** 统一算好展示用的金额，避免在 WXML 里做运算 */
  setItems(rawItems) {
    const items = rawItems.map((item) => ({
      ...item,
      priceText: formatPrice(item.price),
      subtotalText: formatPrice(item.price * item.count)
    }))

    const total = calcTotal(items.map((i) => ({ price: i.price, count: i.count })))
    const totalCount = items.reduce((sum, i) => sum + i.count, 0)

    this.setData({
      items,
      totalText: formatPrice(total),
      totalCount
    })
  },

  /** 表单输入：用 data-field 指定要写入 address 的哪个字段 */
  onAddressInput(e) {
    const field = e.currentTarget.dataset.field
    if (!field) return

    const patch = { [`address.${field}`]: e.detail.value }

    // 一改动就清掉该字段的错误提示，不必等到再次提交
    if (field === 'name' || field === 'phone' || field === 'detail') {
      if (this.data.errors[field]) patch[`errors.${field}`] = ''
    }

    this.setData(patch)
  },

  /**
   * 省市区三级联动。
   * e.detail.value 形如 ['广东省','深圳市','南山区']；直辖市会返回
   * ['北京市','北京市','朝阳区']（省与市同名），这里按原样存，
   * 展示交给 formatRegion 去重 —— 与 CLAUDE.md 的地址快照结构保持一致。
   */
  onRegionChange(e) {
    const value = (e.detail && e.detail.value) || []
    const province = value[0] || ''
    const city = value[1] || ''
    const district = value[2] || ''

    this.setData({
      'address.province': province,
      'address.city': city,
      'address.district': district,
      regionValue: [province, city, district],
      regionText: formatRegion(province, city, district),
      'errors.region': ''
    })
  },

  /**
   * 一键粘贴：把剪贴板里的整段收货信息拆成各字段。
   * wx.getClipboardData 要求由用户手势触发，因此挂在按钮的 bindtap 上。
   */
  onPasteAddress() {
    wx.getClipboardData({
      success: (res) => {
        const text = String((res && res.data) || '').trim()
        if (!text) {
          wx.showToast({ title: '剪贴板是空的', icon: 'none' })
          return
        }
        this.applyParsedAddress(parseAddressText(text))
      },
      fail: (err) => {
        console.error('[FreshBuy] 读取剪贴板失败', err)
        wx.showToast({ title: '读取剪贴板失败，请手动填写', icon: 'none' })
      }
    })
  },

  /**
   * 把解析结果填进表单。
   * 只覆盖**解析出内容**的字段：粘贴不该把用户已经填好的部分清空。
   * 解析是启发式的，结果一律可再手改，不替代下方的 validate。
   */
  applyParsedAddress(parsed) {
    const next = { ...this.data.address }
    const fields = ['name', 'phone', 'province', 'city', 'district', 'detail']

    let hit = 0
    fields.forEach((field) => {
      const value = String(parsed[field] || '').trim()
      if (value) {
        next[field] = value
        hit++
      }
    })

    if (hit === 0) {
      wx.showToast({ title: '这段文字里没认出地址，请手动填写', icon: 'none', duration: 2500 })
      return
    }

    // 邮编必须清掉，不能沿用上一个地址的。
    // 粘贴的整段文字里从来不带邮编，留着旧值等于把「上一个收货地址的邮编」
    // 悄悄写进这一次的订单快照 —— 而表单已不提供邮编输入框，用户看不见也改不了。
    next.postalCode = ''

    // 整段重填过地址，旧的错误提示一并清掉
    this.setData({ address: next, errors: { ...EMPTY_ERRORS } })
    this.refreshRegion()

    wx.showToast({ title: `已识别 ${hit} 项，请核对`, icon: 'none', duration: 2000 })
  },

  /**
   * 拉取微信地址簿预填。
   * 用户拒绝授权时降级为全手动填写，不得阻断下单流程。
   */
  onChooseAddress() {
    wx.chooseAddress({
      success: (res) => {
        // 微信返回的字段名与本项目约定的 address 结构不同，逐项映射
        this.setData({
          address: {
            name: res.userName || '',
            phone: res.telNumber || '',
            province: res.provinceName || '',
            city: res.cityName || '',
            district: res.countyName || '',
            detail: res.detailInfo || '',
            postalCode: res.postalCode || '' // 可能为空串，按空串处理
          },
          errors: { ...EMPTY_ERRORS }
        })
        this.refreshRegion()
      },
      fail: (err) => {
        console.warn('[FreshBuy] 获取微信地址失败，降级为手动填写', err)
        const msg = (err && err.errMsg) || ''
        // 用户主动取消不提示，其余情况给一句轻提示
        if (msg.indexOf('cancel') === -1) {
          wx.showToast({ title: '未能获取微信地址，请手动填写', icon: 'none' })
        }
      }
    })
  },

  /**
   * 逐字段校验。
   * 前端先做一遍，减少无谓的云函数调用；云函数端还会再校验一次，
   * 两边的规则保持一致（见 cloudfunctions/createOrder 的 normalizeAddress）。
   *
   * @return {Object} 键为字段名，值为空串表示该字段没问题
   */
  buildAddressErrors() {
    const a = this.data.address
    const errors = { ...EMPTY_ERRORS }

    if (!String(a.name).trim()) errors.name = '请填写收货人姓名'
    if (!/^[\d\s-]{6,20}$/.test(String(a.phone).trim())) errors.phone = '请填写正确的手机号'
    // 省市区由同一个 picker 给出，缺任何一项都提示同一句话
    if (!String(a.province).trim() || !String(a.city).trim() || !String(a.district).trim()) {
      errors.region = '请选择省 / 市 / 区'
    }
    if (!String(a.detail).trim()) errors.detail = '请填写详细地址'

    return errors
  },

  onSubmit() {
    if (this.data.submitting) return

    if (this.data.items.length === 0) {
      wx.showToast({ title: '没有可下单的商品', icon: 'none' })
      return
    }

    const errors = this.buildAddressErrors()
    if (errors.name || errors.phone || errors.region || errors.detail) {
      this.setData({ errors })
      wx.showToast({ title: '请检查收货地址', icon: 'none' })
      return
    }
    this.setData({ errors: { ...EMPTY_ERRORS } })

    this.setData({ submitting: true })
    wx.showLoading({ title: '提交中…', mask: true })

    const items = this.data.items.map((item) => ({
      productId: item.productId,
      count: item.count
    }))
    const address = this.data.address

    wx.cloud.callFunction({
      name: 'createOrder',
      data: { items, address, saveAddress: true },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '下单失败', icon: 'none' })
          return
        }

        // 下单已成功，后续都是收尾动作，任一失败都不回滚订单
        this.clearCartIfNeeded()
        this.rememberAddressLocally(address)

        wx.showToast({ title: '下单成功', icon: 'success' })
        setTimeout(() => {
          wx.redirectTo({ url: '/sub-buyer/pages/order-list/order-list' })
        }, 800)
      },
      fail: (err) => {
        console.error('[FreshBuy] 创建订单失败', err)

        // 云函数未部署时也走 fail（报 FunctionName not found），
        // 一律提示「网络异常」会把人往网络方向带偏
        const msg = String((err && (err.errMsg || err.message)) || '')
        const notDeployed = /FunctionName|-501000|not found/i.test(msg)

        wx.showToast({
          title: notDeployed ? '请先部署 createOrder 云函数' : '网络异常，请稍后重试',
          icon: 'none',
          duration: 3000
        })
      },
      complete: () => {
        wx.hideLoading()
        this.setData({ submitting: false })
      }
    })
  },

  /** 来自购物车时，清掉已下单的条目 */
  clearCartIfNeeded() {
    if (this.data.mode !== 'cart' || this.data.cartIds.length === 0) return

    wx.cloud.callFunction({
      name: 'removeCart',
      data: { cartIds: this.data.cartIds },
      fail: (err) => {
        console.error('[FreshBuy] 清空购物车条目失败（不影响下单）', err)
      }
    })
  },

  /** 本地也记一份，避免用户不重启小程序时地址栏空着 */
  rememberAddressLocally(address) {
    const app = getApp()
    if (!app.globalData.userInfo) app.globalData.userInfo = {}
    app.globalData.userInfo.address = address
  }
})
