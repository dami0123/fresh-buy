// sub-buyer/pages/detail/detail.js —— 商品详情
// 读取单个商品属于读操作，按 CLAUDE.md 约定可直接使用云数据库；
// 一切写操作（加购、下单）必须经由云函数。
const { formatPrice, calcTotal } = require('../../../utils/format')

const db = wx.cloud.database()

Page({
  data: {
    productId: '',
    product: null,
    count: 1,
    totalText: '0.00',
    stockText: '',
    loading: true,
    error: '',
    soldOut: false,
    submitting: false,
    adding: false
  },

  onLoad(options) {
    const productId = options && options.id
    if (!productId) {
      this.setData({ loading: false, error: '缺少商品参数' })
      return
    }
    this.setData({ productId })
    this.loadProduct(productId)
  },

  /** 读取商品详情 */
  loadProduct(productId) {
    db.collection('products')
      .doc(productId)
      .get()
      .then((res) => {
        const product = res.data
        const stock = Number(product.stock) || 0
        product.priceText = formatPrice(product.price)

        this.setData({
          product,
          // 售罄时置灰底部两个按钮，避免用户点了才被云函数拒绝
          soldOut: stock <= 0,
          // 文案在 JS 里算好，WXML 只负责输出（CLAUDE.md 前端规范）
          stockText: stock <= 0 ? '已售罄' : `库存 ${stock}`,
          loading: false
        })
        this.refreshTotal()
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取商品详情失败', err)

        // 详情页是「前端直读数据库」，与首页走云函数不同，它受集合读权限限制。
        // 最常见且最难自查的失败原因就是权限，这里直接把排查方向写进页面，
        // 避免只显示一句「商品不存在」让人误以为数据没造成功。
        const msg = String((err && (err.errMsg || err.message)) || '')
        const isPermission = /permission|denied|not authorized/i.test(msg)

        this.setData({
          loading: false,
          error: isPermission
            ? '读不到商品：请到云开发控制台 → 数据库 → products → 权限设置，改为「所有人可读」'
            : '商品不存在或已被下架'
        })
      })
  },

  /** 数量 -1 */
  onMinus() {
    // 到下限时给出反馈，否则点上去毫无反应，看起来像按钮坏了
    if (this.data.count <= 1) {
      wx.showToast({ title: '数量不能再少了', icon: 'none' })
      return
    }
    this.setData({ count: this.data.count - 1 })
    this.refreshTotal()
  },

  /** 数量 +1，不超过库存 */
  onPlus() {
    const { product, count } = this.data
    if (!product) return

    const stock = Number(product.stock) || 0
    if (stock <= 0) {
      wx.showToast({ title: '该商品已售罄', icon: 'none' })
      return
    }
    if (count >= stock) {
      wx.showToast({ title: '已达库存上限', icon: 'none' })
      return
    }
    this.setData({ count: count + 1 })
    this.refreshTotal()
  },

  /** 重算合计金额 */
  refreshTotal() {
    const { product, count } = this.data
    if (!product) return
    const total = calcTotal([{ price: product.price, count }])
    this.setData({ totalText: formatPrice(total) })
  },

  /**
   * 加入购物车
   * 写操作一律经云函数（CLAUDE.md「API调用」），商品现价与库存由云函数以数据库为准校验。
   */
  onAddToCart() {
    if (this.data.adding) return

    const { product, count } = this.data
    if (!product) return

    this.setData({ adding: true })

    wx.cloud.callFunction({
      name: 'addToCart',
      data: { productId: this.data.productId, count },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '加入购物车失败', icon: 'none' })
          return
        }
        wx.showToast({ title: '已加入购物车', icon: 'success' })
      },
      fail: (err) => {
        console.error('[FreshBuy] 加入购物车失败', err)

        // 云函数压根没部署时也会走 fail（报 FunctionName not found），
        // 如果一律提示「网络异常」，会让人往网络方向排查，白费功夫。
        const msg = String((err && (err.errMsg || err.message)) || '')
        const notDeployed = /FunctionName|-501000|not found/i.test(msg)

        wx.showToast({
          title: notDeployed ? '请先部署 addToCart 云函数' : '网络异常，请稍后重试',
          icon: 'none',
          duration: 3000
        })
      },
      complete: () => {
        this.setData({ adding: false })
      }
    })
  },

  /**
   * 立即购买 —— 跳确认下单页填写收货地址，由该页调 createOrder 下单。
   * 不再直接下单：本项目要求订单一律带地址快照（CLAUDE.md「地址快照原则」）。
   */
  onBuyNow() {
    if (this.data.submitting) return

    const { product, count } = this.data
    if (!product) return

    wx.navigateTo({
      url: `/sub-buyer/pages/order-confirm/order-confirm?mode=detail&productId=${this.data.productId}&count=${count}`,
      fail: (err) => {
        console.error('[FreshBuy] 跳转确认下单页失败', err)
        wx.showToast({ title: '页面跳转失败', icon: 'none' })
      }
    })
  }
})
