// sub-buyer/pages/cart/cart.js —— 购物车
//
// 读操作直接查库（按 userId 过滤，且 cart 集合权限为「仅创建者可读写」时
// 云函数写入的 _openid 会再做一层兜底过滤）。
// 增删改一律经 addToCart / updateCartCount / removeCart 云函数，禁止前端直写。
const { formatPrice, calcTotal } = require('../../../utils/format')

const db = wx.cloud.database()

Page({
  data: {
    carts: [],       // 购物车条目（含商品快照信息）
    totalCount: 0,
    totalText: '0.00',
    loading: true,
    error: '',
    updating: false  // 防止连点造成数量与服务端不一致
  },

  onShow() {
    this.loadCart()
  },

  onPullDownRefresh() {
    this.loadCart(() => wx.stopPullDownRefresh())
  },

  /** 读取当前用户的购物车 */
  loadCart(done) {
    const app = getApp()
    const openid = app.globalData.openid

    if (!openid) {
      this.setData({ loading: false, error: '未获取到登录信息，请返回首页重新登录' })
      if (typeof done === 'function') done()
      return
    }

    this.setData({ loading: true, error: '' })

    db.collection('cart')
      .where({ userId: openid })
      .orderBy('createTime', 'desc')
      .get()
      .then((res) => {
        this.setData({ loading: false })
        this.refreshTotals(res.data || [])
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取购物车失败', err)
        this.setData({ loading: false, error: '加载失败，请稍后重试' })
      })
      .then(() => {
        if (typeof done === 'function') done()
      })
  },

  /** 统一重算小计与合计，避免在 WXML 里做运算 */
  refreshTotals(carts) {
    const list = (carts || []).map((item) => ({
      ...item,
      priceText: formatPrice(item.price),
      subtotalText: formatPrice(Number(item.price || 0) * Number(item.count || 0))
    }))

    const total = calcTotal(list.map((i) => ({ price: i.price, count: i.count })))
    const totalCount = list.reduce((sum, i) => sum + Number(i.count || 0), 0)

    this.setData({
      carts: list,
      totalCount,
      totalText: formatPrice(total)
    })
  },

  /** 数量 -1 */
  onMinus(e) {
    const cart = this.findCart(e.currentTarget.dataset.id)
    if (!cart) return

    const next = Number(cart.count) - 1
    if (next < 1) {
      wx.showToast({ title: '数量不能再少了，可点「删除」移除', icon: 'none' })
      return
    }
    this.changeCount(cart._id, next)
  },

  /** 数量 +1，上限由云函数按商品库存校验 */
  onPlus(e) {
    const cart = this.findCart(e.currentTarget.dataset.id)
    if (!cart) return
    this.changeCount(cart._id, Number(cart.count) + 1)
  },

  findCart(id) {
    return this.data.carts.find((item) => item._id === id)
  },

  /**
   * 修改数量：先本地更新保证点按手感，再以云函数返回为准；
   * 失败时重新拉取服务端数据纠正本地状态。
   * updating 作为在途锁，防止连点导致本地值与服务端漂移。
   */
  changeCount(cartId, count) {
    if (this.data.updating) return

    const carts = this.data.carts.map((item) =>
      item._id === cartId ? { ...item, count } : item
    )
    this.setData({ updating: true })
    this.refreshTotals(carts)

    wx.cloud.callFunction({
      name: 'updateCartCount',
      data: { cartId, count },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '修改失败', icon: 'none' })
          this.loadCart()
        }
      },
      fail: (err) => {
        console.error('[FreshBuy] 修改购物车数量失败', err)
        wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
        this.loadCart()
      },
      complete: () => {
        this.setData({ updating: false })
      }
    })
  },

  /** 删除条目 */
  onRemove(e) {
    const cartId = e.currentTarget.dataset.id
    if (!cartId) return

    wx.showModal({
      title: '删除商品',
      content: '确认从购物车移除该商品？',
      success: (res) => {
        if (res.confirm) this.callRemoveCart(cartId)
      }
    })
  },

  callRemoveCart(cartId) {
    wx.showLoading({ title: '删除中…', mask: true })

    wx.cloud.callFunction({
      name: 'removeCart',
      data: { cartId },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '删除失败', icon: 'none' })
          return
        }
        wx.showToast({ title: '已删除', icon: 'success' })
        this.loadCart()
      },
      fail: (err) => {
        console.error('[FreshBuy] 删除购物车条目失败', err)
        wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },

  /**
   * 结算 —— 跳确认下单页填写收货地址，由该页调 createOrder。
   * 不再直接下单：本项目要求订单一律带地址快照（CLAUDE.md「地址快照原则」）。
   */
  onCheckout() {
    if (this.data.carts.length === 0) {
      wx.showToast({ title: '购物车是空的', icon: 'none' })
      return
    }

    wx.navigateTo({
      url: '/sub-buyer/pages/order-confirm/order-confirm?mode=cart',
      fail: (err) => {
        console.error('[FreshBuy] 跳转确认下单页失败', err)
        wx.showToast({ title: '页面跳转失败', icon: 'none' })
      }
    })
  },

  /** 去逛逛 */
  onGoHome() {
    wx.navigateBack({
      fail: () => wx.redirectTo({ url: '/sub-buyer/pages/home/home' })
    })
  }
})
