// sub-buyer/pages/return-apply/return-apply.js —— 退货申请 / 售后
//
// 一个页面承担四件事，用 view 字段区分（由订单状态与 return 子对象推导）：
//   apply     可申请：上传退货照片 -> applyReturn（内部同步调 aiJudge）
//   resolve   已判商家责任（status=5）：展示「退款 / 重发」选择 -> resolveReturn
//   rejected  判定非商家责任：展示「售后未通过」与理由（订单已自动回退到 4）
//   refunded / reshipped  已处理完：只读展示结果
//
// ⚠️ 判定由系统自动完成且为终局，本页不提供任何申诉入口（CLAUDE.md 已知限制 #3）。
const { formatTime, formatPrice } = require('../../../utils/format')
const { toDate, toDisplayUrls } = require('../../utils/display')
const { ORDER_STATUS, ORDER_STATUS_TEXT } = require('../../../utils/constant')

const MAX_PHOTOS = 9 // 与 applyReturn 云函数的上限保持一致

Page({
  data: {
    orderId: '',
    order: null,
    view: '',
    statusText: '',
    totalPriceText: '',
    createTimeText: '',
    receiveAtText: '',
    refundAtText: '',
    shipPhotos: [],
    returnPhotos: [],
    judgeReason: '',
    liable: null,

    // 待上传的本地照片临时路径
    localPhotos: [],

    loading: true,
    submitting: false,
    error: ''
  },

  onLoad(options) {
    const orderId = options && options.orderId
    if (!orderId) {
      this.setData({ loading: false, error: '缺少订单参数' })
      return
    }
    this.setData({ orderId })
  },

  onShow() {
    if (this.data.orderId) {
      this.loadOrder()
    }
  },

  loadOrder() {
    this.setData({ loading: true, error: '' })

    wx.cloud.callFunction({
      name: 'getMyOrders',
      data: { orderId: this.data.orderId },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          this.setData({ loading: false, error: result.msg || '加载失败' })
          return
        }
        this.applyOrder(result.order || {})
      },
      fail: (err) => {
        console.error('[FreshBuy] 读取订单失败', err)
        this.setData({ loading: false, error: '网络异常，请稍后重试' })
      }
    })
  },

  applyOrder(order) {
    const status = Number(order.status)
    const ret = order.return || {}

    this.setData({
      order,
      view: this.resolveView(status, ret),
      statusText: ORDER_STATUS_TEXT[status] || '未知',
      totalPriceText: formatPrice(order.totalPrice),
      createTimeText: formatTime(toDate(order.createTime)),
      receiveAtText: formatTime(toDate(order.receiveAt)),
      refundAtText: formatTime(toDate(ret.refundAt)),
      judgeReason: ret.reason || '',
      liable: typeof ret.liable === 'boolean' ? ret.liable : null,
      loading: false
    })

    toDisplayUrls(order.shipPhotos).then((list) => this.setData({ shipPhotos: list }))
    toDisplayUrls(ret.photos).then((list) => this.setData({ returnPhotos: list }))
  },

  /** 由订单状态与售后子对象推导本页该展示哪种形态 */
  resolveView(status, ret) {
    if (ret.resolution === 'rejected') return 'rejected'
    if (ret.resolution === 'refund') return 'refunded'
    if (ret.resolution === 'reship') return 'reshipped'
    if (status === ORDER_STATUS.AFTER_SALE && ret.liable === true) return 'resolve'
    if (status === ORDER_STATUS.DELIVERING || status === ORDER_STATUS.FINISHED) return 'apply'
    return 'locked'
  },

  // ---------------- 上传退货照片 ----------------

  onChoosePhotos() {
    const remain = MAX_PHOTOS - this.data.localPhotos.length
    if (remain <= 0) {
      wx.showToast({ title: `最多上传 ${MAX_PHOTOS} 张`, icon: 'none' })
      return
    }

    wx.chooseMedia({
      count: remain,
      mediaType: ['image'],
      // TODO(上线前必改)：CLAUDE.md「发货照片约定」要求强制相机（sourceType: ['camera']），
      // 开发期放开相册是因为开发者工具模拟器调不起相机，照此实现会导致无法自测。
      // 上线前必须改回 ['camera']，这是已知技术债。
      sourceType: ['camera', 'album'],
      sizeType: ['compressed'],
      success: (res) => {
        const paths = (res.tempFiles || []).map((file) => file.tempFilePath)
        this.setData({ localPhotos: this.data.localPhotos.concat(paths) })
      },
      fail: (err) => {
        console.warn('[FreshBuy] 选择照片失败或已取消', err)
      }
    })
  },

  /** 预览本地待上传的照片 */
  onPreviewLocal(e) {
    const index = Number(e.currentTarget.dataset.index) || 0
    wx.previewImage({ current: this.data.localPhotos[index], urls: this.data.localPhotos })
  },

  onRemoveLocal(e) {
    const index = Number(e.currentTarget.dataset.index)
    const list = this.data.localPhotos.slice()
    list.splice(index, 1)
    this.setData({ localPhotos: list })
  },

  onPreviewReturnPhoto(e) {
    const index = Number(e.currentTarget.dataset.index) || 0
    wx.previewImage({ current: this.data.returnPhotos[index], urls: this.data.returnPhotos })
  },

  onPreviewShipPhoto(e) {
    const index = Number(e.currentTarget.dataset.index) || 0
    wx.previewImage({ current: this.data.shipPhotos[index], urls: this.data.shipPhotos })
  },

  // ---------------- 提交售后申请 ----------------

  onSubmit() {
    if (this.data.submitting) return

    const photos = this.data.localPhotos
    if (photos.length === 0) {
      wx.showToast({ title: '请至少上传 1 张退货照片', icon: 'none' })
      return
    }

    this.setData({ submitting: true })
    wx.showLoading({ title: '提交中…', mask: true })

    this.uploadAll(photos)
      .then((fileIds) => this.callApplyReturn(fileIds))
      .catch((err) => {
        console.error('[FreshBuy] 上传退货照片失败', err)
        wx.showToast({ title: '照片上传失败，请重试', icon: 'none' })
      })
      .then(() => {
        wx.hideLoading()
        this.setData({ submitting: false })
      })
  },

  /** 逐张上传到云存储，数据库只存 fileID（符合「图片处理」规范） */
  uploadAll(paths) {
    const tasks = paths.map((path, index) => {
      const match = path.match(/\.[a-zA-Z0-9]+$/)
      const ext = match ? match[0] : '.jpg'
      return new Promise((resolve, reject) => {
        wx.cloud.uploadFile({
          cloudPath: `return/${this.data.orderId}_${Date.now()}_${index}${ext}`,
          filePath: path,
          success: (res) => resolve(res.fileID),
          fail: reject
        })
      })
    })
    return Promise.all(tasks)
  },

  callApplyReturn(fileIds) {
    return new Promise((resolve) => {
      wx.cloud.callFunction({
        name: 'applyReturn',
        data: { orderId: this.data.orderId, photos: fileIds },
        success: (res) => {
          const result = res.result || {}
          if (result.code !== 0) {
            // 鉴别服务不可用时订单状态不变，可稍后重试
            wx.showToast({ title: result.msg || '提交失败', icon: 'none' })
            resolve()
            return
          }
          wx.showToast({
            title: result.liable ? '判定为商家责任' : '售后未通过',
            icon: 'none'
          })
          this.setData({ localPhotos: [] })
          this.loadOrder()
          resolve()
        },
        fail: (err) => {
          console.error('[FreshBuy] 发起售后失败', err)
          wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
          resolve()
        }
      })
    })
  },

  // ---------------- 处理售后结果（买家选择退款或重发）----------------

  onChooseResolution(e) {
    const resolution = e.currentTarget.dataset.resolution
    if (resolution !== 'refund' && resolution !== 'reship') return

    const isRefund = resolution === 'refund'

    wx.showModal({
      title: isRefund ? '确认退款' : '确认重发货',
      content: isRefund
        ? '确认后订单将关闭。本流程无真实资金流转，退款仅为状态记录。'
        : '商家将重新拍照发货，订单回到「待发货」。',
      success: (res) => {
        if (res.confirm) this.callResolveReturn(resolution)
      }
    })
  },

  callResolveReturn(resolution) {
    if (this.data.submitting) return
    this.setData({ submitting: true })
    wx.showLoading({ title: '处理中…', mask: true })

    wx.cloud.callFunction({
      name: 'resolveReturn',
      data: { orderId: this.data.orderId, resolution },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '操作失败', icon: 'none' })
          return
        }
        wx.showToast({
          title: resolution === 'refund' ? '已退款' : '已通知商家重发',
          icon: 'success'
        })
        this.loadOrder()
      },
      fail: (err) => {
        console.error('[FreshBuy] 售后处理失败', err)
        wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
      },
      complete: () => {
        wx.hideLoading()
        this.setData({ submitting: false })
      }
    })
  },

  /** 回到订单详情 */
  onBackToOrder() {
    wx.navigateBack({
      fail: () => wx.redirectTo({ url: '/sub-buyer/pages/order-list/order-list' })
    })
  }
})
