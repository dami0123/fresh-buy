// sub-buyer/seedProducts —— 开发期测试数据：商品造数（原 cloudfunctions/seedProducts，2026-09-19 移入本目录）
// 依据 CLAUDE.md「开发期测试数据约定」：商品覆盖 vegetable / fruit / meat / seafood 四个分类。
// 当前共 60 条（每分类 15 条），远超 home.js 的 PAGE_SIZE=10，用于验证 getProducts 的分页与上拉加载。
//
// 数据集刻意做的两个设计：
//   1. 每个分类各有 1 条 `stock: 0` 的商品（search「售罄」），用来验证买家端的售罄表现
//      —— 首页商品图压暗 + 库存文案转红、详情页「加入购物车」置灰。
//      没有 sort=0 的样本，这条路径就等于没测过。
//   2. 价格跨度 2.5 ~ 168 元，覆盖「按价格看排版会不会撑破」的边界。
//
// 商品图：全部为 Wikimedia Commons 的实拍图，按商品逐个挑选核对过，与商品名对应
// （此前用的 picsum.photos 是随机风景照，和商品毫无关系，已全部替换）。
//   · 地址形如 https://thumb.wikimedia.org/.../960px-<文件名>.jpg
//   · 免费、无水印，可直接外链；已实测在开发者的网络环境下可正常加载
//   · 换图只需改下面的 images 数组，重新部署并执行一次，函数会把已存在商品的 images 同步过去
//
// ⚠️ 开发期专用，上线前删除本函数：
//   商品图用的是**网络直链**而非云存储 fileID，与 CLAUDE.md「图片处理」规范冲突，
//   属已拍板的开发期临时妥协。上线前必须改为「图片传云存储 + 库里只存 fileID」，
//   届时 <image> 的 src 取值方式同步调整（fileID 不能直接当 URL 用）。
//   注意外链图片还可能被对方撤下或限流，这正是必须改成云存储的原因。
//
// 幂等：执行前按 name 查重。已存在且 images 一致则跳过；images 对不上只更新图片字段，
// 不碰价格与库存。可反复执行而不产生脏数据，改了图片也能一次同步到位。
//
// 怎么跑：这个函数没有挂任何前端入口，请到
//   开发者工具 → 云开发 → 云函数 → seedProducts → 「云端测试」→ 运行
// 控制台测试不带用户登录态（OPENID 为空），函数内会识别这种情况并跳过商家校验；
// 从小程序端调用时该校验照常生效。详见 exports.main 里的说明。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command
const products = db.collection('products')
const users = db.collection('users')

/**
 * 60 条商品，每分类 15 条。
 * category 取值与 home.js 的静态分类、categories.key 严格对齐。
 * 字段遵循 CLAUDE.md「数据库规范 → products」：name / price / stock / category / images / status / createTime。
 *
 * 想再加商品：往下面数组里追加一条即可（name 唯一），重新部署本函数后再执行一次，
 * 幂等逻辑会只插入缺失的那些。也可以把整条数组留空、改用云控制台手工插入，
 * 但字段必须齐全，尤其 status 与 createTime（getProducts 依赖 createTime 排序）。
 */
const SEED_PRODUCTS = [
  // ==================== vegetable 蔬菜 ====================
  {
    name: '有机西红柿',
    price: 5.8,
    stock: 120,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/89/Tomato_je.jpg/960px-Tomato_je.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/88/Bright_red_tomato_and_cross_section02.jpg/960px-Bright_red_tomato_and_cross_section02.jpg'
    ]
  },
  {
    name: '新鲜黄瓜',
    price: 3.5,
    stock: 200,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/93/Ryerson_Market_cucumbers_on_sale.jpg/960px-Ryerson_Market_cucumbers_on_sale.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/86/Cucumber_in_jaffna.JPG/960px-Cucumber_in_jaffna.JPG'
    ]
  },
  {
    name: '上海青',
    price: 4.2,
    stock: 150,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/8c/Brassica_rapa_var._chinensis_%28leaf%29.jpg/960px-Brassica_rapa_var._chinensis_%28leaf%29.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/1d/Brassica_rapa_chinensis_4610994.jpg/960px-Brassica_rapa_chinensis_4610994.jpg'
    ]
  },
  {
    name: '黄心土豆',
    price: 2.9,
    stock: 300,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6e/Potato_tubers_in_pail.jpg/960px-Potato_tubers_in_pail.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6a/Solanum_tuberosum_Red_Scarlett20170523_7825.jpg/960px-Solanum_tuberosum_Red_Scarlett20170523_7825.jpg'
    ]
  },
  {
    name: '紫皮洋葱',
    price: 3.2,
    stock: 180,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/9f/Red_Onion_on_White.JPG/960px-Red_Onion_on_White.JPG',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/94/Three_whole_red_onions.jpg/960px-Three_whole_red_onions.jpg'
    ]
  },
  {
    name: '有机西兰花',
    price: 6.5,
    stock: 90,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/03/Broccoli_and_cross_section_edit.jpg/960px-Broccoli_and_cross_section_edit.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/48/Broccoli_florets_on_ice.jpg/960px-Broccoli_florets_on_ice.jpg'
    ]
  },
  {
    name: '山东大葱',
    price: 2.5,
    stock: 260,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/da/CSA-Red-Spring-Onions.jpg/960px-CSA-Red-Spring-Onions.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/ce/Bunches_of_spring_onions_1.jpg/960px-Bunches_of_spring_onions_1.jpg'
    ]
  },
  {
    name: '嫩姜',
    price: 7.8,
    stock: 110,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/fb/Fresh_ginger_rhizome_01.jpg/960px-Fresh_ginger_rhizome_01.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/8a/Ginger_rhizomes.jpg/960px-Ginger_rhizomes.jpg'
    ]
  },
  {
    name: '鲜香菇',
    price: 9.9,
    stock: 85,
    category: 'vegetable',
    images: [
      'https://upload.wikimedia.org/wikipedia/commons/6/65/Lentinula_edodes.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7c/Lentinula_edodes_20101113_a.jpg/960px-Lentinula_edodes_20101113_a.jpg'
    ]
  },
  {
    name: '金针菇',
    price: 4.5,
    stock: 140,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/00/Salad_enoki_mushrooms.jpg/960px-Salad_enoki_mushrooms.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/9f/Mushroom_Reference_-11.jpg/960px-Mushroom_Reference_-11.jpg'
    ]
  },
  {
    name: '紫甘蓝',
    price: 5.2,
    stock: 95,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/eb/Abstrakte_Fotografie_001_2012_10_16.jpg/960px-Abstrakte_Fotografie_001_2012_10_16.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/31/Modra_kapusta_po_poznansku.jpg/960px-Modra_kapusta_po_poznansku.jpg'
    ]
  },
  {
    name: '奶油生菜',
    price: 6.8,
    stock: 120,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6b/Romaine_lettuce.jpg/960px-Romaine_lettuce.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7b/Lactuca_sativa_%27Ashbrook%27.jpg/960px-Lactuca_sativa_%27Ashbrook%27.jpg'
    ]
  },
  {
    name: '水果玉米',
    price: 8.8,
    stock: 76,
    category: 'vegetable',
    images: [
      'https://upload.wikimedia.org/wikipedia/commons/7/79/VegCorn.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6e/Steamed_corn_on_the_cob_in_Moran_Market.jpg/960px-Steamed_corn_on_the_cob_in_Moran_Market.jpg'
    ]
  },
  {
    name: '铁棍山药',
    price: 12.5,
    stock: 64,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b2/Yam_tuber.jpg/960px-Yam_tuber.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/1e/Yam_Tubers_stacked_on_a_plastic_table_01.jpg/960px-Yam_Tubers_stacked_on_a_plastic_table_01.jpg'
    ]
  },
  {
    // 售罄样本：验证首页商品图压暗、库存文案转红、详情页按钮置灰
    name: '有机菠菜',
    price: 5.9,
    stock: 0,
    category: 'vegetable',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/2b/Spinacia_oleracea_bd-3.jpg/960px-Spinacia_oleracea_bd-3.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f7/Spinacia_oleracea_bd-2.jpg/960px-Spinacia_oleracea_bd-2.jpg'
    ]
  },

  // ==================== fruit 水果 ====================
  {
    name: '红富士苹果',
    price: 12.8,
    stock: 80,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/15/Red_Apple.jpg/960px-Red_Apple.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/99/Apples_in_basket_2018_G2.jpg/960px-Apples_in_basket_2018_G2.jpg'
    ]
  },
  {
    name: '海南香蕉',
    price: 8.9,
    stock: 100,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/98/Bananas_on_black_background_02.jpg/960px-Bananas_on_black_background_02.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/31/Cavendish_banana_from_Maracaibo.jpg/960px-Cavendish_banana_from_Maracaibo.jpg'
    ]
  },
  {
    name: '阳光玫瑰葡萄',
    price: 25.6,
    stock: 60,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/8a/Green_Grape_3.jpg/960px-Green_Grape_3.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/5/5e/Wine_grapes03.jpg/960px-Wine_grapes03.jpg'
    ]
  },
  {
    name: '赣南脐橙',
    price: 16.8,
    stock: 70,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e3/Oranges_-_whole-halved-segment.jpg/960px-Oranges_-_whole-halved-segment.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c4/Orange-Fruit-Pieces.jpg/960px-Orange-Fruit-Pieces.jpg'
    ]
  },
  {
    name: '麒麟西瓜',
    price: 22.0,
    stock: 45,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d9/%D8%A7%D9%84%D8%A8%D8%B7%D9%8A%D8%AE_%D8%A7%D9%84%D8%A3%D8%AD%D9%85%D8%B1.JPG/960px-%D8%A7%D9%84%D8%A8%D8%B7%D9%8A%D8%AE_%D8%A7%D9%84%D8%A3%D8%AD%D9%85%D8%B1.JPG',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/87/Citrullus_lanatus_%28fruit%29_1_2018-06-02.jpg/960px-Citrullus_lanatus_%28fruit%29_1_2018-06-02.jpg'
    ]
  },
  {
    name: '云南蓝莓',
    price: 39.9,
    stock: 55,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7d/Dish_of_blueberries.jpg/960px-Dish_of_blueberries.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0b/Blueberries-In-Pack.jpg/960px-Blueberries-In-Pack.jpg'
    ]
  },
  {
    name: '山东大樱桃',
    price: 59.9,
    stock: 30,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/bb/Cherry_Stella444.jpg/960px-Cherry_Stella444.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a5/Sweet_cherries_in_basket_2018_G1.jpg/960px-Sweet_cherries_in_basket_2018_G1.jpg'
    ]
  },
  {
    name: '泰国金枕榴莲',
    price: 128.0,
    stock: 12,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/37/Durian_Fruit_in_Yunnan.jpg/960px-Durian_Fruit_in_Yunnan.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0b/Durian_fruit_opened_PJ_DSC_0802.jpg/960px-Durian_fruit_opened_PJ_DSC_0802.jpg'
    ]
  },
  {
    name: '四川爱媛果冻橙',
    price: 19.8,
    stock: 68,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/49/Mandarin_Oranges_%28Citrus_Reticulata%29.jpg/960px-Mandarin_Oranges_%28Citrus_Reticulata%29.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/2f/Citrus_reticulata_fruit_2009_G1.jpg/960px-Citrus_reticulata_fruit_2009_G1.jpg'
    ]
  },
  {
    name: '新疆库尔勒香梨',
    price: 14.5,
    stock: 88,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/99/Four_pears.jpg/960px-Four_pears.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/5/5d/Pear_DS.jpg/960px-Pear_DS.jpg'
    ]
  },
  {
    name: '海南红心火龙果',
    price: 16.9,
    stock: 52,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7e/Dragon_Fruit_02.jpg/960px-Dragon_Fruit_02.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/5/55/Dragon_Fruit_01.jpg/960px-Dragon_Fruit_01.jpg'
    ]
  },
  {
    name: '云南沃柑',
    price: 13.8,
    stock: 73,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/4c/Tangerine_2009-03-11.jpg/960px-Tangerine_2009-03-11.jpg',
      'https://upload.wikimedia.org/wikipedia/commons/2/2a/TangerineFruit.jpg'
    ]
  },
  {
    name: '陕西冬枣',
    price: 24.9,
    stock: 41,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e3/Ziziphus_mauritiana_jujube_fruit.jpg/960px-Ziziphus_mauritiana_jujube_fruit.jpg',
      'https://upload.wikimedia.org/wikipedia/commons/8/80/Jujube_fruit.jpg'
    ]
  },
  {
    name: '智利进口车厘子',
    price: 89.0,
    stock: 18,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/bb/Cherry_Stella444.jpg/960px-Cherry_Stella444.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a5/Sweet_cherries_in_basket_2018_G1.jpg/960px-Sweet_cherries_in_basket_2018_G1.jpg'
    ]
  },
  {
    // 售罄样本
    name: '越南白心百香果',
    price: 11.5,
    stock: 0,
    category: 'fruit',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0e/Passionfruit_and_cross_section.jpg/960px-Passionfruit_and_cross_section.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/21/Passion_fruits_-_whole_and_halved.jpg/960px-Passion_fruits_-_whole_and_halved.jpg'
    ]
  },

  // ==================== meat 肉禽蛋 ====================
  {
    name: '黑猪五花肉',
    price: 32.0,
    stock: 50,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/49/Schweinebauch-2.jpg/960px-Schweinebauch-2.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/20/A_Pork_Belly_at_home.jpg/960px-A_Pork_Belly_at_home.jpg'
    ]
  },
  {
    name: '精选牛腩块',
    price: 45.5,
    stock: 40,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e6/Brisket_topped_with_fat_-_Decmeber_2023_-_Sarah_Stierch.jpg/960px-Brisket_topped_with_fat_-_Decmeber_2023_-_Sarah_Stierch.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a5/Assorted_Raw_Beef%2C_Pork_%26_Chicken_Slices_for_Yakiniku.jpg/960px-Assorted_Raw_Beef%2C_Pork_%26_Chicken_Slices_for_Yakiniku.jpg'
    ]
  },
  {
    name: '农家土鸡蛋',
    price: 15.8,
    stock: 90,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/12/6-Pack-Chicken-Eggs.jpg/960px-6-Pack-Chicken-Eggs.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/83/Egg_cartons_with_chicken_eggs_03.jpg/960px-Egg_cartons_with_chicken_eggs_03.jpg'
    ]
  },
  {
    name: '散养土鸡',
    price: 78.0,
    stock: 20,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f5/Whole_raw_chicken_-_Japan_Dec_22_2019.jpeg/960px-Whole_raw_chicken_-_Japan_Dec_22_2019.jpeg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c7/Raw_chicken_for_sale.jpg/960px-Raw_chicken_for_sale.jpg'
    ]
  },
  {
    name: '内蒙古羊肉卷',
    price: 52.8,
    stock: 35,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d6/Lamb_meat.jpg/960px-Lamb_meat.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/38/Raw_lamb_cutlets_with_shredded_ginger_and_rosemary.jpg/960px-Raw_lamb_cutlets_with_shredded_ginger_and_rosemary.jpg'
    ]
  },
  {
    name: '黑猪肋排',
    price: 46.0,
    stock: 40,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d0/Pork_ribs_%281%29.jpg/960px-Pork_ribs_%281%29.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0d/Raw_pork_spareribs.jpg/960px-Raw_pork_spareribs.jpg'
    ]
  },
  {
    name: '精修牛肉卷',
    price: 49.9,
    stock: 36,
    category: 'meat',
    images: [
      'https://upload.wikimedia.org/wikipedia/commons/6/60/Standing-rib-roast.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/bc/Raw_Beef_at_Barkin_Dogo_Market_04.jpg/960px-Raw_Beef_at_Barkin_Dogo_Market_04.jpg'
    ]
  },
  {
    name: '新鲜猪里脊',
    price: 28.5,
    stock: 55,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/5/59/Pork_loin.jpg/960px-Pork_loin.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/91/Pork_loin_%281027276219%29.jpg/960px-Pork_loin_%281027276219%29.jpg'
    ]
  },
  {
    name: '黑猪梅花肉',
    price: 38.8,
    stock: 42,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/40/HK_food_ingredient_red_meat_frozen_pork_chop_raw_butt_steak_October_2021_SS2_013.jpg/960px-HK_food_ingredient_red_meat_frozen_pork_chop_raw_butt_steak_October_2021_SS2_013.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/9c/HK_food_ingredient_red_meat_frozen_pork_chop_raw_butt_steak_October_2021_SS2_015.jpg/960px-HK_food_ingredient_red_meat_frozen_pork_chop_raw_butt_steak_October_2021_SS2_015.jpg'
    ]
  },
  {
    name: '农家咸鸭蛋',
    price: 22.0,
    stock: 60,
    category: 'meat',
    images: [
      'https://upload.wikimedia.org/wikipedia/commons/e/e6/Salty_egg.JPG',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/01/Salted_duck_egg_yolk.jpg/960px-Salted_duck_egg_yolk.jpg'
    ]
  },
  {
    name: '现杀麻鸭',
    price: 68.0,
    stock: 16,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/ff/Raw_duck_feet.jpg/960px-Raw_duck_feet.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e6/Duck_with_apples.jpg/960px-Duck_with_apples.jpg'
    ]
  },
  {
    name: '澳洲谷饲牛排',
    price: 88.0,
    stock: 22,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/14/Raw_steak.jpg/960px-Raw_steak.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/95/Raw_beef_steak%2C_2011.jpg/960px-Raw_beef_steak%2C_2011.jpg'
    ]
  },
  {
    name: '精选鸡中翅',
    price: 26.8,
    stock: 48,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/8c/Raw_chicken_wings.jpg/960px-Raw_chicken_wings.jpg',
      'https://upload.wikimedia.org/wikipedia/commons/4/42/Plucked_chicken_wing.jpg'
    ]
  },
  {
    name: '潮汕手打牛肉丸',
    price: 35.0,
    stock: 44,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e0/HK_Pacific_Plaza_SYP_%E5%BE%B7%E9%9F%BE%E8%8B%91_Tak_Hing_Yuen_Seafood_Restaurant_beef_meat_balls_Mar-2013_Bamboo_steamer.JPG/960px-HK_Pacific_Plaza_SYP_%E5%BE%B7%E9%9F%BE%E8%8B%91_Tak_Hing_Yuen_Seafood_Restaurant_beef_meat_balls_Mar-2013_Bamboo_steamer.JPG',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/de/Steamed_beef_meatballs_at_Tim_Ho_Wan%2C_Sham_Shui_Po_%2820180908160733%29.jpg/960px-Steamed_beef_meatballs_at_Tim_Ho_Wan%2C_Sham_Shui_Po_%2820180908160733%29.jpg'
    ]
  },
  {
    // 售罄样本
    name: '有机乌鸡',
    price: 82.0,
    stock: 0,
    category: 'meat',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e2/Silky_bantam.jpg/960px-Silky_bantam.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/bf/A_muffed_silkie_cock_in_Gyeonggido_Gwangju.jpg/960px-A_muffed_silkie_cock_in_Gyeonggido_Gwangju.jpg'
    ]
  },

  // ==================== seafood 水产 ====================
  {
    name: '鲜活基围虾',
    price: 58.0,
    stock: 30,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/12/HK_food_%E6%80%A5%E5%87%8D_frozen_food_%E8%9D%A6%E4%BB%81_peeled_prawn_in_June_2022_Px3_05_cropped.jpg/960px-HK_food_%E6%80%A5%E5%87%8D_frozen_food_%E8%9D%A6%E4%BB%81_peeled_prawn_in_June_2022_Px3_05_cropped.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/43/Prawns_-_%E0%A4%B8%E0%A5%81%E0%A4%82%E0%A4%97%E0%A4%9F%E0%A4%BE.jpg/960px-Prawns_-_%E0%A4%B8%E0%A5%81%E0%A4%82%E0%A4%97%E0%A4%9F%E0%A4%BE.jpg'
    ]
  },
  {
    name: '冰鲜三文鱼排',
    price: 68.5,
    stock: 25,
    category: 'seafood',
    images: [
      'https://upload.wikimedia.org/wikipedia/commons/4/48/Raw_salmon_2.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/0a/Baked_salmon_2.jpg/960px-Baked_salmon_2.jpg'
    ]
  },
  {
    name: '大连生蚝',
    price: 39.9,
    stock: 35,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/37/Oysters_p1040741.jpg/960px-Oysters_p1040741.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e9/Oyster_shells_on_Whitstable_beach.jpg/960px-Oyster_shells_on_Whitstable_beach.jpg'
    ]
  },
  {
    name: '鲜活小龙虾',
    price: 88.0,
    stock: 15,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/a/a9/Usfws-guyandotte-river-crayfish-large.jpg/960px-Usfws-guyandotte-river-crayfish-large.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/ce/Usfws-st-francis-river-crayfish-large.jpg/960px-Usfws-st-francis-river-crayfish-large.jpg'
    ]
  },
  {
    name: '冰鲜黄花鱼',
    price: 42.5,
    stock: 28,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/32/Yellow_croaker_%28Larimichthys%29.jpg/960px-Yellow_croaker_%28Larimichthys%29.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d2/Frozen-fresh_yellow_croaker.jpg/960px-Frozen-fresh_yellow_croaker.jpg'
    ]
  },
  {
    name: '冷冻扇贝柱',
    price: 56.0,
    stock: 32,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/77/Frozen_scallop_meat_%2820240124%29.jpg/960px-Frozen_scallop_meat_%2820240124%29.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b3/Frozen_scallop_meat.jpg/960px-Frozen_scallop_meat.jpg'
    ]
  },
  {
    name: '阳澄湖大闸蟹',
    price: 168.0,
    stock: 10,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d5/Zoo_K%C3%B6ln_Eriocheir_sinensis_31122014_1_bis.jpg/960px-Zoo_K%C3%B6ln_Eriocheir_sinensis_31122014_1_bis.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/17/Zoo_K%C3%B6ln_Eriocheir_sinensis_31122014_2_bis.jpg/960px-Zoo_K%C3%B6ln_Eriocheir_sinensis_31122014_2_bis.jpg'
    ]
  },
  {
    name: '冰鲜鲈鱼',
    price: 32.8,
    stock: 26,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b8/Giant_Sea_Bass%2C_CAS.jpg/960px-Giant_Sea_Bass%2C_CAS.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/76/Stereolepis_gigas_239967891.jpg/960px-Stereolepis_gigas_239967891.jpg'
    ]
  },
  {
    name: '鲜活梭子蟹',
    price: 76.0,
    stock: 14,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/2f/Liocarcinus_depurator.jpg/960px-Liocarcinus_depurator.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b1/Specimen_of_Charybdis_orientalis.JPG/960px-Specimen_of_Charybdis_orientalis.JPG'
    ]
  },
  {
    name: '挪威北极甜虾',
    price: 62.0,
    stock: 24,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/78/Liat_Portal_for_Foodie_Disorder_-_Fresh_jumbo_shrimp_from_San_Francisco_farmers_market.jpg/960px-Liat_Portal_for_Foodie_Disorder_-_Fresh_jumbo_shrimp_from_San_Francisco_farmers_market.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d7/Raw_Shrimp_on_Plate_1_2017-01-22.jpg/960px-Raw_Shrimp_on_Plate_1_2017-01-22.jpg'
    ]
  },
  {
    name: '鲜活花甲',
    price: 18.5,
    stock: 45,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/f/f6/Giant_clam_black%26white_komodo.jpg/960px-Giant_clam_black%26white_komodo.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/1c/Mya_arenaria_01.jpg/960px-Mya_arenaria_01.jpg'
    ]
  },
  {
    name: '深海带鱼段',
    price: 45.0,
    stock: 33,
    category: 'seafood',
    images: [
      'https://upload.wikimedia.org/wikipedia/commons/8/87/Trichiurus_lepturus_SI.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/96/Trichiurus_lepturus_in_market.jpg/960px-Trichiurus_lepturus_in_market.jpg'
    ]
  },
  {
    name: '精选鱿鱼须',
    price: 38.5,
    stock: 29,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/0/08/Frozen_fresh_squid_head.jpg/960px-Frozen_fresh_squid_head.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/5/5c/Squid%2C_with_a_real_camera_-_Flickr_-_Stewart.jpg/960px-Squid%2C_with_a_real_camera_-_Flickr_-_Stewart.jpg'
    ]
  },
  {
    name: '冰鲜鲍鱼',
    price: 138.0,
    stock: 8,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/21/Haliotis_laevigata_01.JPG/960px-Haliotis_laevigata_01.JPG',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/33/LivingAbalone.JPG/960px-LivingAbalone.JPG'
    ]
  },
  {
    // 售罄样本
    name: '冷冻鳕鱼块',
    price: 58.0,
    stock: 0,
    category: 'seafood',
    images: [
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/76/Frozen_cod_tail.jpg/960px-Frozen_cod_tail.jpg',
      'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e4/Sous_vide_cod_2018.jpg/960px-Sous_vide_cod_2018.jpg'
    ]
  }
]

/** 两个图片数组是否完全一致（含顺序），用于判断已存在的商品要不要更新 images */
function isSameImages(current, seed) {
  if (!Array.isArray(current) || current.length !== seed.length) return false
  return seed.every((url, i) => current[i] === url)
}

exports.main = async () => {
  const wxContext = cloud.getWXContext()
  const { OPENID, SOURCE } = wxContext

  try {
    // ---- 权限校验 ----
    // 正常路径：小程序端调用，平台会注入 OPENID，必须查库确认 role === 'seller'，
    // 不信任前端传入的任何身份信息。
    //
    // 特例：OPENID 为空。官方 getWXContext 字段说明里，OPENID 一栏的「字段存在条件」
    // 是「小程序端调用云函数时」—— 反过来说，空 OPENID 意味着这次调用**不来自小程序**，
    // 只可能是云控制台的「云端测试」（SOURCE 为 wx_devtools），而控制台测试不带用户
    // 登录态，没有 openid 可查，商家校验无从谈起，因此放行。
    //
    // 小程序客户端无法伪造出「空 OPENID」——OPENID 由平台注入，不由调用方提供。
    // 所以这个分支不会成为绕过口：从小程序调进来时，商家校验一行都没少。
    if (!OPENID) {
      console.log('[seedProducts] 无 OPENID，判定为控制台调用，跳过商家校验。SOURCE =', SOURCE)
    } else {
      const userRes = await users.where({ openid: OPENID }).limit(1).get()
      if (userRes.data.length === 0) {
        return { code: -2, msg: '用户不存在，请先进入小程序完成一次登录' }
      }
      if (userRes.data[0].role !== 'seller') {
        return {
          code: -2,
          msg: '无权限：仅商家可造测试数据。请在云控制台把 users 中本账号的 role 改为 seller，清缓存后重试'
        }
      }
    }

    // ---- 幂等：按 name 查出已存在的商品，缺的插入、图片对不上的更新 ----
    //
    // 「已存在就跳过」在只加商品时够用，但改了图片地址就没辙了：代码里换成了新图，
    // 库里还是上一次留下的旧地址，重新运行本函数会全部跳过，界面上看不出任何变化，
    // 很容易被误判成「云函数没生效」。
    //
    // 所以对已存在的记录再比对一次 images：不一致就单独更新这一个字段。
    // **只动 images**，不碰 price / stock / status —— 这几项在演示过程中可能被手工调过
    // （比如为了演示「售罄」把库存改成 0），每次执行都覆盖回去反而是帮倒忙。
    // 比对一致则跳过，因此反复执行仍然不产生任何变化，幂等性没有被破坏。
    const names = SEED_PRODUCTS.map((item) => item.name)
    const existingRes = await products
      .where({ name: _.in(names) })
      .field({ name: true, images: true })
      .get()
    const existingImages = new Map(
      (existingRes.data || []).map((item) => [item.name, item.images || []])
    )

    const inserted = []
    const updated = []
    const skipped = []

    for (let i = 0; i < SEED_PRODUCTS.length; i++) {
      const item = SEED_PRODUCTS[i]

      if (existingImages.has(item.name)) {
        if (isSameImages(existingImages.get(item.name), item.images)) {
          skipped.push(item.name)
          continue
        }

        await products.where({ name: item.name }).update({
          data: { images: item.images, updateTime: new Date() }
        })
        updated.push(item.name)
        continue
      }

      // createTime 依次递减（数组靠前 = 越新），保证 getProducts 的
      // orderBy('createTime', 'desc') 排序稳定可预期。
      //
      // 间隔取 1 秒而非 1 分钟：幂等跳过意味着老数据的时间戳是「上一次执行」留下的，
      // 而数组末尾新增的商品只有在时间戳晚于老数据时才会出现在列表前面。
      // 用 1 分钟间隔的话，新增的第 25 条会落在「上次执行时间 - 24 分钟」，
      // 比老数据更旧，直接被埋到最后一页，界面上看不出加过东西。
      const createTime = new Date(Date.now() - i * 1000)

      await products.add({
        data: {
          name: item.name,
          price: item.price,
          stock: item.stock,
          category: item.category,
          images: item.images,
          status: 1, // 1 上架 / 0 下架
          createTime,
          updateTime: createTime
        }
      })

      inserted.push(item.name)
    }

    return {
      code: 0,
      msg: `造数完成：新增 ${inserted.length} 条，更新图片 ${updated.length} 条，跳过 ${skipped.length} 条（已存在且图片一致）`,
      inserted,
      updated,
      skipped
    }
  } catch (err) {
    console.error('[seedProducts] 造数失败', err)
    return {
      code: -1,
      msg: '造数失败，请确认 products 集合已创建且数据库权限配置正确'
    }
  }
}
