// cloudfunctions/createOrder —— 创建订单
//
// 安全约定（CLAUDE.md「商家端特别约定」）：前端只传 productId 与数量，
// 商品单价与订单总价一律在服务端依据数据库现价重新计算，杜绝前端篡改金额。
//
// 库存约定（CLAUDE.md「库存扣减约定」）：扣库存与写订单必须在同一事务内完成，
// 任一步失败整体回滚；扣减用 _.inc(-count) 原子写法，禁止「先读出来再写回去」。
//
// 地址约定（CLAUDE.md「收货地址约定」）：下单必须携带完整地址，且**按快照写入**订单，
// 不得只存 users 的引用或 _id —— 否则用户事后改收货地址会污染历史订单。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command
const users = db.collection('users')
const orders = db.collection('orders')

const MAX_ITEM_KINDS = 20 // 单笔订单最多包含的商品种类
const MAX_COUNT_PER_ITEM = 99

/** 地址必填字段（postalCode 允许为空串 —— wx.chooseAddress 常返回空串） */
const ADDRESS_REQUIRED = ['name', 'phone', 'province', 'city', 'district', 'detail']

/** 生成订单号：年月日时分秒 + 4 位随机数 */
function generateOrderNo() {
  const now = new Date()
  const pad = (n) => (n < 10 ? '0' + n : '' + n)
  const stamp = [
    now.getFullYear(),
    pad(now.getMonth() + 1),
    pad(now.getDate()),
    pad(now.getHours()),
    pad(now.getMinutes()),
    pad(now.getSeconds())
  ].join('')
  const rand = Math.floor(Math.random() * 10000)
  return stamp + String(rand).padStart(4, '0')
}

/**
 * 归一化并校验收货地址。
 * @return {Object|null} 合法时返回结构固定的地址快照，否则返回 null
 */
function normalizeAddress(input) {
  if (!input || typeof input !== 'object') return null

  const addr = {
    name: String(input.name || '').trim(),
    phone: String(input.phone || '').trim(),
    province: String(input.province || '').trim(),
    city: String(input.city || '').trim(),
    district: String(input.district || '').trim(),
    detail: String(input.detail || '').trim(),
    postalCode: String(input.postalCode || '').trim() // 可能为空串，按空串处理即可
  }

  for (const key of ADDRESS_REQUIRED) {
    if (!addr[key]) return null
  }

  // 手机号做宽松校验：允许数字、空格与连字符，长度 6~20
  if (!/^[\d\s-]{6,20}$/.test(addr.phone)) return null

  return addr
}

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { items = [], address = null, saveAddress = false } = event

  // ---- 参数校验 ----
  if (!Array.isArray(items) || items.length === 0) {
    return { code: -1, msg: '订单商品不能为空' }
  }
  if (items.length > MAX_ITEM_KINDS) {
    return { code: -1, msg: `单笔订单最多支持 ${MAX_ITEM_KINDS} 种商品` }
  }

  // 地址为必填：没有地址快照的订单在商家端无法发货
  const addressSnapshot = normalizeAddress(address)
  if (!addressSnapshot) {
    return { code: -1, msg: '请填写完整的收货地址（收货人、手机号、省市区与详细地址）' }
  }

  const ids = items.map((item) => item.productId).filter(Boolean)
  if (ids.length !== items.length) {
    return { code: -1, msg: '订单商品参数不完整' }
  }

  let transaction = null

  try {
    transaction = await db.startTransaction()

    /** 中止事务并返回业务错误 */
    const abort = async (msg) => {
      await transaction.rollback().catch(() => {})
      transaction = null
      return { code: -1, msg }
    }

    // ---- 事务内逐项重新校验库存并扣减 ----
    const orderItems = []
    let totalPrice = 0

    for (const item of items) {
      const count = Math.floor(Number(item.count))
      if (!Number.isFinite(count) || count <= 0) {
        return await abort('购买数量不合法')
      }
      if (count > MAX_COUNT_PER_ITEM) {
        return await abort(`单件商品最多购买 ${MAX_COUNT_PER_ITEM} 件`)
      }

      // 事务内重新读取，保证读到的是最新库存（事务外的读取可能已过期）
      const productRes = await transaction
        .collection('products')
        .doc(item.productId)
        .get()
        .catch(() => null)

      const product = productRes && productRes.data
      if (!product) {
        return await abort('订单中包含不存在的商品')
      }
      // 仅在显式下架时拒绝：部分历史数据可能没有 status 字段，不应因此误伤
      if (Number(product.status) === 0) {
        return await abort(`「${product.name}」已下架`)
      }

      const stock = Number(product.stock) || 0
      if (stock < count) {
        return await abort(`「${product.name}」库存不足，仅剩 ${stock} 件`)
      }

      // 金额一律取服务端的 product.price，忽略前端传入的任何价格字段
      totalPrice += Number(product.price) * count

      // 原子扣减，禁止「先读出来再写回去」
      await transaction.collection('products').doc(item.productId).update({
        data: { stock: _.inc(-count), updateTime: new Date() }
      })

      orderItems.push({
        productId: product._id,
        name: product.name,
        price: Number(product.price),
        count,
        image: (product.images && product.images[0]) || ''
      })
    }

    // 避免浮点误差，保留两位小数
    totalPrice = Number(totalPrice.toFixed(2))

    // ---- 写入订单 ----
    const now = new Date()
    const order = {
      orderNo: generateOrderNo(),
      userId: OPENID,
      items: orderItems,
      totalPrice,
      status: 1, // 1:待发货 2:待确认发货 3:配送中 4:已完成 5:售后中 6:已关闭
      address: addressSnapshot, // 地址快照，非引用
      shipPhotos: [],
      shipRejectReason: '',
      reshipCount: 0,
      createTime: now,
      updateTime: now
    }

    const addRes = await transaction.collection('orders').add({ data: order })

    await transaction.commit()
    transaction = null

    // ---- 地址记忆：回写常用地址，供下次下单预填 ----
    // 包在 try/catch 内，回写失败不影响下单结果
    if (saveAddress) {
      try {
        await users.where({ openid: OPENID }).update({
          data: { address: addressSnapshot, updateTime: new Date() }
        })
      } catch (err) {
        console.error('[createOrder] 回写常用地址失败（不影响下单）', err)
      }
    }

    return {
      code: 0,
      msg: '下单成功',
      orderId: addRes._id,
      orderNo: order.orderNo,
      totalPrice
    }
  } catch (err) {
    if (transaction) {
      await transaction.rollback().catch(() => {})
    }
    console.error('[createOrder] 创建订单失败', err)
    return { code: -1, msg: '下单失败，请稍后重试' }
  }
}
