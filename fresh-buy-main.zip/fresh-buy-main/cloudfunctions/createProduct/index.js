// cloudfunctions/createProduct —— 商家新增商品
//
// 安全约定（CLAUDE.md「商家端特别约定」）：金额、库存等在云函数端二次校验，
// 不信任前端传入；调用者身份查 users 集合确认 role === 'seller'。
//
// 服务端补 createTime / updateTime；status 缺省按 1（上架）处理。
// category 白名单与 utils/category.js、categories.key 约定对齐。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const users = db.collection('users')
const products = db.collection('products')

// 分类白名单：与 categories.key / home.js 静态分类 / utils/category.js 严格对齐
const CATEGORY_KEYS = ['vegetable', 'fruit', 'meat', 'seafood']
const NAME_MAX_LEN = 30
const MAX_PRICE = 999999 // 金额上限，防异常值

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()

  // ---- 参数提取与二次校验（不信任前端）----
  const name = String(event.name || '').trim()
  const price = Number(event.price)
  const stock = Math.floor(Number(event.stock))
  const category = String(event.category || '')
  const images = Array.isArray(event.images)
    ? event.images.filter((item) => typeof item === 'string' && item)
    : []
  const status = Number(event.status) === 0 ? 0 : 1 // 缺省上架，只允许 0 / 1

  if (!name) {
    return { code: -1, msg: '请填写商品名称' }
  }
  if (name.length > NAME_MAX_LEN) {
    return { code: -1, msg: `商品名称最多 ${NAME_MAX_LEN} 字` }
  }
  if (!Number.isFinite(price) || price <= 0 || price > MAX_PRICE) {
    return { code: -1, msg: '商品价格不合法' }
  }
  if (!Number.isFinite(stock) || stock < 0) {
    return { code: -1, msg: '库存不能为负数' }
  }
  if (!CATEGORY_KEYS.includes(category)) {
    return { code: -1, msg: '商品分类不合法' }
  }
  if (images.length === 0) {
    return { code: -1, msg: '请至少上传 1 张商品图片' }
  }

  try {
    // ---- 权限校验：以数据库中的 role 为准 ----
    const userRes = await users.where({ openid: OPENID }).limit(1).get()
    const role = userRes.data[0] && userRes.data[0].role
    if (role !== 'seller') {
      return { code: -2, msg: '无权限操作，仅商家可新增商品' }
    }

    const now = new Date()
    const addRes = await products.add({
      data: {
        name,
        price: Number(price.toFixed(2)),
        stock,
        category,
        images,
        status,
        createTime: now,
        updateTime: now
      }
    })

    return { code: 0, msg: '商品已创建', productId: addRes._id }
  } catch (err) {
    console.error('[createProduct] 创建商品失败', err)
    return { code: -1, msg: '创建失败，请稍后重试' }
  }
}
