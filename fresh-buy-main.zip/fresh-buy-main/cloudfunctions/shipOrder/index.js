// cloudfunctions/shipOrder —— 商家上传 3 张发货照片，订单进入「待确认发货」
//
// 状态机（CLAUDE.md「订单状态机」）：
//   1 待发货     -> 2 待确认发货（首次发货）
//   2 待确认发货 -> 2（买家驳回后重新拍照，覆盖上一轮照片）
//
// 越权校验（CLAUDE.md「越权校验约定」）：查 users 集合确认 role === 'seller'，
// 不得信任前端传入的 role（可被伪造）。
//
// 照片约定（CLAUDE.md「发货照片约定」）：照片固定 3 张，不足 3 张前端禁用提交，
// 云函数端同样强校验「恰好 3 张」。照片为云存储 fileID（前端已 uploadFile）。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const users = db.collection('users')
const orders = db.collection('orders')

const SHIP_PHOTO_COUNT = 3 // 发货照片固定 3 张
const STATUS_PENDING_SHIP = 1
const STATUS_PENDING_CONFIRM_SHIP = 2

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId } = event
  const photos = Array.isArray(event.photos) ? event.photos.filter(Boolean) : []

  // ---- 参数校验 ----
  if (!orderId) {
    return { code: -1, msg: '缺少订单 ID' }
  }
  if (photos.length !== SHIP_PHOTO_COUNT) {
    return { code: -1, msg: `请上传 ${SHIP_PHOTO_COUNT} 张发货照片（当前 ${photos.length} 张）` }
  }
  if (photos.some((photo) => typeof photo !== 'string')) {
    return { code: -1, msg: '照片参数不合法' }
  }

  try {
    // ---- 权限校验：以数据库中的 role 为准 ----
    const userRes = await users.where({ openid: OPENID }).limit(1).get()
    const role = userRes.data[0] && userRes.data[0].role
    if (role !== 'seller') {
      return { code: -2, msg: '无权限操作，仅商家可发货' }
    }

    // ---- 确认订单存在 ----
    const orderRes = await orders.doc(orderId).get().catch(() => null)
    if (!orderRes || !orderRes.data) {
      return { code: -1, msg: '订单不存在' }
    }

    // ---- 状态校验：1 首次发货；2 买家驳回后重新拍照 ----
    const status = Number(orderRes.data.status)
    if (status !== STATUS_PENDING_SHIP && status !== STATUS_PENDING_CONFIRM_SHIP) {
      return { code: -1, msg: '当前订单状态不可上传发货照片' }
    }

    await orders.doc(orderId).update({
      data: {
        status: STATUS_PENDING_CONFIRM_SHIP,
        shipPhotos: photos,
        shipRejectReason: '', // 重拍时清掉上一轮的驳回原因
        updateTime: new Date()
      }
    })

    return { code: 0, msg: '发货照片已提交，等待买家确认', status: STATUS_PENDING_CONFIRM_SHIP }
  } catch (err) {
    console.error('[shipOrder] 上传发货照片失败', err)
    return { code: -1, msg: '操作失败，请稍后重试' }
  }
}
