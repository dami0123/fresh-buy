// cloudfunctions/devAdvanceOrder —— 【开发期专用】订单状态推进调试工具
//
// ⚠️⚠️ 开发期专用，上线前必须删除本函数 ⚠️⚠️
//
// 存在的理由：同伴 B 的 shipOrder（拍照发货）尚未实现，订单无法从「待发货」走到
// 2/3/4/5/6，买家端的「确认发货照片 / 驳回 / 确认收货 / 发起售后」四条分支
// 在本函数到位前完全无法自测。本函数仿 seedProducts 的先例，提供一条临时通路。
//
// ⚠️ 与「发货照片约定」冲突：默认用 picsum 网络占位图代替真实拍照（数据库只存 fileID
//    是正式规范）。这是已拍板的开发期临时妥协，上线前连同本函数一起删除。
//    开发者工具需勾选「不校验合法域名」才能显示占位图。
//
// 权限：调用者必须是该订单的归属买家（order.userId === OPENID），或 role === 'seller'。
//       其余一律拒绝（role 以数据库为准，不信任前端传入）。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const users = db.collection('users')
const orders = db.collection('orders')

/** 默认发货占位图：固定 3 张，模拟商家拍照发货 */
const PLACEHOLDER_SHIP_PHOTOS = [
  'https://picsum.photos/seed/fb-ship-a/600/600',
  'https://picsum.photos/seed/fb-ship-b/600/600',
  'https://picsum.photos/seed/fb-ship-c/600/600'
]

const STATUS_PENDING_CONFIRM_SHIP = 2
const STATUS_DELIVERING = 3
const STATUS_FINISHED = 4

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId, action } = event

  if (!orderId) {
    return { code: -1, msg: '缺少订单 ID' }
  }
  if (!action) {
    return { code: -1, msg: '缺少 action 参数' }
  }

  try {
    const orderRes = await orders.doc(orderId).get().catch(() => null)
    if (!orderRes || !orderRes.data) {
      return { code: -1, msg: '订单不存在' }
    }

    const order = orderRes.data

    // ---- 权限校验：订单归属人本人，或商家 ----
    let allowed = order.userId === OPENID
    if (!allowed) {
      const userRes = await users.where({ openid: OPENID }).limit(1).get()
      const role = userRes.data[0] && userRes.data[0].role
      allowed = role === 'seller'
    }
    if (!allowed) {
      return { code: -2, msg: '无权操作该订单（仅订单本人或商家可调用调试接口）' }
    }

    const now = new Date()
    const data = { updateTime: now }
    let tip = ''

    switch (action) {
      // 模拟商家拍照发货：1 待发货 -> 2 待确认发货
      case 'ship': {
        const photos = Array.isArray(event.photos) && event.photos.length
          ? event.photos
          : PLACEHOLDER_SHIP_PHOTOS
        data.status = STATUS_PENDING_CONFIRM_SHIP
        data.shipPhotos = photos
        data.shipRejectReason = '' // 重拍时清掉上一轮的驳回原因
        tip = '已模拟商家发货（3 张照片）'
        break
      }

      // 模拟买家确认发货照片：2 待确认发货 -> 3 配送中
      case 'deliver': {
        data.status = STATUS_DELIVERING
        tip = '已模拟确认发货照片'
        break
      }

      // 模拟买家确认收货：-> 4 已完成
      // hoursAgo 用于把 receiveAt 设为 N 小时之前，便于测 aiJudge 的 48 小时判定分界
      case 'receive': {
        const hoursAgo = Number(event.hoursAgo) || 0
        data.status = STATUS_FINISHED
        data.receiveAt = new Date(now.getTime() - hoursAgo * 3600000)
        tip = hoursAgo > 0
          ? `已模拟确认收货（receiveAt 回拨 ${hoursAgo} 小时）`
          : '已模拟确认收货'
        break
      }

      default:
        return { code: -1, msg: 'action 仅支持 ship / deliver / receive' }
    }

    await orders.doc(orderId).update({ data })

    return { code: 0, msg: tip, status: data.status }
  } catch (err) {
    console.error('[devAdvanceOrder] 推进状态失败', err)
    return { code: -1, msg: '操作失败，请稍后重试' }
  }
}
