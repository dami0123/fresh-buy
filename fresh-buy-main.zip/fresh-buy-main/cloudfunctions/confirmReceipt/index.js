// cloudfunctions/confirmReceipt —— 买家确认收货
//
// 状态机：3 配送中 -> 4 已完成，并写入 receiveAt。
// receiveAt 是 aiJudge 计算「确认收货 -> 发起售后」时间差的依据，必须在这里落库。
//
// 越权校验：以 getWXContext() 的 OPENID 与订单 userId 比对。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const orders = db.collection('orders')

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId } = event

  if (!orderId) {
    return { code: -1, msg: '缺少订单 ID' }
  }

  try {
    const orderRes = await orders.doc(orderId).get().catch(() => null)
    if (!orderRes || !orderRes.data) {
      return { code: -1, msg: '订单不存在' }
    }

    const order = orderRes.data

    // ---- 越权校验 ----
    if (order.userId !== OPENID) {
      return { code: -2, msg: '无权操作该订单' }
    }

    // ---- 状态校验：只有「配送中」才能确认收货 ----
    if (Number(order.status) !== 3) {
      return { code: -1, msg: '当前订单状态不可确认收货' }
    }

    const now = new Date()

    await orders.doc(orderId).update({
      data: {
        status: 4,
        receiveAt: now, // 售后判定时间差的起点
        updateTime: now
      }
    })

    return { code: 0, msg: '已确认收货', status: 4 }
  } catch (err) {
    console.error('[confirmReceipt] 确认收货失败', err)
    return { code: -1, msg: '操作失败，请稍后重试' }
  }
}
