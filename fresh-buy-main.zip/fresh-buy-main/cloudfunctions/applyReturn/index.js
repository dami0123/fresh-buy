// cloudfunctions/applyReturn —— 买家发起售后
//
// 流程（CLAUDE.md「售后判定约定」）：
//   1. 校验订单归属与状态（3 配送中 / 4 已完成 可发起）
//   2. 按订单计算 hoursSinceReceive，连同一组照片一起交给 aiJudge
//   3. liable === true  -> status = 5 售后中，由买家在 resolveReturn 选择退款或重发
//      liable === false -> status = 4 已完成（自动回退），写 return.resolution = 'rejected'
//
// ⚠️ 判责由系统自动完成且为终局，商家端只有查看权，不提供人工改判按钮。
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const orders = db.collection('orders')

const MAX_PHOTOS = 9
const MAX_TRY_PER_DAY = 5 // 同一订单每日售后提交上限（CLAUDE.md：防止刷接口）

const STATUS_DELIVERING = 3
const STATUS_FINISHED = 4
const STATUS_AFTER_SALE = 5

/** 当天日期 YYYY-MM-DD，用于按天限流 */
function today() {
  const now = new Date()
  const pad = (n) => (n < 10 ? '0' + n : '' + n)
  return [now.getFullYear(), pad(now.getMonth() + 1), pad(now.getDate())].join('-')
}

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId } = event
  const photos = Array.isArray(event.photos) ? event.photos.filter(Boolean) : []

  // ---- 参数校验 ----
  if (!orderId) {
    return { code: -1, msg: '缺少订单 ID' }
  }
  if (photos.length === 0) {
    return { code: -1, msg: '请至少上传 1 张退货照片' }
  }
  if (photos.length > MAX_PHOTOS) {
    return { code: -1, msg: `最多上传 ${MAX_PHOTOS} 张照片` }
  }

  try {
    const orderRes = await orders.doc(orderId).get().catch(() => null)
    if (!orderRes || !orderRes.data) {
      return { code: -1, msg: '订单不存在' }
    }

    const order = orderRes.data

    // ---- 越权校验 ----
    if (order.userId !== OPENID) {
      return { code: -2, msg: '无权操作该订单' }
    }

    // ---- 状态校验 ----
    const status = Number(order.status)
    if (status !== STATUS_DELIVERING && status !== STATUS_FINISHED) {
      return { code: -1, msg: '当前订单状态不可发起售后' }
    }

    // ---- 终局性校验 ----
    // 判定为非商家责任后订单会回到 4（已完成），若不加这道拦截，买家可以反复上传
    // 更多照片重试，等价于刷出一条「申诉通道」。CLAUDE.md 已知限制 #3 明确一期
    // 不提供申诉入口，故此处直接拒绝。
    if (order.return && order.return.resolution === 'rejected') {
      return { code: -1, msg: '该订单售后已判定为终局结论，无法重复申请' }
    }

    // ---- 限流：失败重试也要计数，防止刷接口 ----
    const day = today()
    const tryCount = order.returnTryDate === day ? Number(order.returnTryCount) || 0 : 0
    if (tryCount >= MAX_TRY_PER_DAY) {
      return { code: -1, msg: `今日售后提交次数已达上限（${MAX_TRY_PER_DAY} 次），请明天再试` }
    }

    // ---- 时间差：从「确认收货」到「发起售后」----
    // status = 3 时买家尚未确认收货，receiveAt 不存在，回退到 updateTime
    // （最近一次状态变更时间），保证 aiJudge 始终拿得到有效输入。
    const receiveAt = order.receiveAt || order.updateTime || order.createTime
    const receiveTime = receiveAt ? new Date(receiveAt).getTime() : Date.now()
    const hoursSinceReceive = Math.max(0, (Date.now() - receiveTime) / 3600000)

    // ---- 调用鉴别服务 ----
    // 失败处理（已拍板）：提示重试，订单状态保持不变，不写入 return 子对象。
    // ⚠️ 禁止降级为「商家责任」—— 否则服务报错会被利用，买家反复提交即可刷出退款。
    // ⚠️ 禁止转人工判定 —— 与「系统自动终局判定」的结论冲突，且商家端页面已按只读设计。
    let judge = null
    try {
      const judgeRes = await cloud.callFunction({
        name: 'aiJudge',
        data: {
          shipPhotos: order.shipPhotos || [], // 由云函数从订单自行读取，不由前端传入
          returnPhotos: photos,
          hoursSinceReceive
        }
      })
      judge = judgeRes && judgeRes.result
    } catch (err) {
      console.error('[applyReturn] 调用 aiJudge 失败', err)
    }

    if (!judge || typeof judge.liable !== 'boolean') {
      // 只累加限流计数，不碰订单状态与 return 子对象
      await orders.doc(orderId).update({
        data: { returnTryCount: tryCount + 1, returnTryDate: day }
      })
      return { code: -1, msg: '鉴别服务暂不可用，请稍后重试' }
    }

    const liable = judge.liable
    const now = new Date()

    // liable = true  -> 5 售后中，等买家选择退款或重发
    // liable = false -> 自动回退到 4 已完成，并写明理由。
    //   买家端必须展示「售后未通过」，否则订单会卡在售后中无人能处理。
    const nextStatus = liable ? STATUS_AFTER_SALE : STATUS_FINISHED

    await orders.doc(orderId).update({
      data: {
        status: nextStatus,
        return: {
          photos,
          aiResult: judge.raw || {}, // 原始输出，永不被业务字段覆盖
          liable,
          reason: judge.reason || '',
          confidence: typeof judge.confidence === 'number' ? judge.confidence : null,
          resolution: liable ? '' : 'rejected',
          refundAt: null,
          applyAt: now
        },
        returnTryCount: tryCount + 1,
        returnTryDate: day,
        updateTime: now
      }
    })

    return {
      code: 0,
      msg: liable ? '鉴别完成：判定为商家责任' : '鉴别完成：售后未通过',
      status: nextStatus,
      liable,
      reason: judge.reason || '',
      confidence: judge.confidence
    }
  } catch (err) {
    console.error('[applyReturn] 发起售后失败', err)
    return { code: -1, msg: '提交失败，请稍后重试' }
  }
}
