// cloudfunctions/getMyOrders —— 查询当前用户的订单
//
// 为什么不走前端直查：orders 集合若配置为「所有人可读」，任何买家都能读到全部订单；
// 用云函数查询可以强制用 getWXContext() 拿到的可信 OPENID 过滤，从根本上保证
// 「只返回本人的订单」，且前端无需放开 orders 集合的读权限。
//
// 两种模式（用是否传 orderId 区分）：
//   1. 传 orderId  -> 返回单条订单（订单详情页），并校验归属
//   2. 不传 orderId -> 按状态分页返回列表（我的订单页），status 省略或传 -1 表示全部
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const orders = db.collection('orders')

const MAX_PAGE_SIZE = 20 // 单次请求上限，防止被恶意拉取全表

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId } = event

  try {
    // ---- 模式一：单条查询 ----
    if (orderId) {
      const res = await orders.doc(orderId).get().catch(() => null)
      if (!res || !res.data) {
        return { code: -1, msg: '订单不存在' }
      }
      if (res.data.userId !== OPENID) {
        return { code: -2, msg: '无权查看该订单' }
      }
      return { code: 0, order: res.data }
    }

    // ---- 模式二：分页列表 ----
    const pageSize = Math.min(Math.max(Number(event.pageSize) || 10, 1), MAX_PAGE_SIZE)
    const page = Math.max(Number(event.page) || 1, 1)
    const status = Number(event.status)

    // status 为 -1、NaN 或未传时表示「全部」，不加状态条件
    const where = { userId: OPENID }
    if (Number.isFinite(status) && status >= 0) {
      where.status = status
    }

    // 分别构造查询：链式方法返回新对象，但分开写更不容易踩到复用查询的坑
    const [listRes, countRes] = await Promise.all([
      orders
        .where(where)
        .orderBy('createTime', 'desc')
        .skip((page - 1) * pageSize)
        .limit(pageSize)
        .get(),
      orders.where(where).count()
    ])

    const total = countRes.total

    return {
      code: 0,
      list: listRes.data,
      total,
      page,
      pageSize,
      hasMore: page * pageSize < total
    }
  } catch (err) {
    console.error('[getMyOrders] 查询失败', err)
    return {
      code: -1,
      msg: '订单加载失败，请确认 orders 集合已创建且数据库权限配置正确',
      list: [],
      total: 0,
      hasMore: false
    }
  }
}
