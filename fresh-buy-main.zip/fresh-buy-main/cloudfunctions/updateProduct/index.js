// cloudfunctions/updateProduct —— 商家更新商品（上下架 / 库存 / 名称 / 价格 / 分类 / 图片）
//
// 安全约定（CLAUDE.md「商家端特别约定」）：
//   - 字段白名单：白名单外的字段一律忽略，防止越权注入（如篡改 createTime）
//   - 金额、库存云函数端二次校验，不信任前端传入
//   - 调用者身份查 users 集合确认 role === 'seller'
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const users = db.collection('users')
const products = db.collection('products')

// 分类白名单：与 categories.key / home.js 静态分类 / utils/category.js 严格对齐
const CATEGORY_KEYS = ['vegetable', 'fruit', 'meat', 'seafood']
const NAME_MAX_LEN = 30
const MAX_PRICE = 999999 // 金额上限，防异常值

exports.main = async (event) => {
  const { OPENID } = cloud.getWXContext()
  const { productId } = event

  if (!productId) {
    return { code: -1, msg: '缺少商品 ID' }
  }

  // ---- 字段白名单：逐项校验，白名单外的字段一律忽略 ----
  const data = {}
  const has = (key) => Object.prototype.hasOwnProperty.call(event, key)

  if (has('name')) {
    const name = String(event.name || '').trim()
    if (!name) return { code: -1, msg: '商品名称不能为空' }
    if (name.length > NAME_MAX_LEN) return { code: -1, msg: `商品名称最多 ${NAME_MAX_LEN} 字` }
    data.name = name
  }
  if (has('price')) {
    const price = Number(event.price)
    if (!Number.isFinite(price) || price <= 0 || price > MAX_PRICE) {
      return { code: -1, msg: '商品价格不合法' }
    }
    data.price = Number(price.toFixed(2))
  }
  if (has('stock')) {
    const stock = Math.floor(Number(event.stock))
    if (!Number.isFinite(stock) || stock < 0) return { code: -1, msg: '库存不能为负数' }
    data.stock = stock
  }
  if (has('category')) {
    const category = String(event.category || '')
    if (!CATEGORY_KEYS.includes(category)) return { code: -1, msg: '商品分类不合法' }
    data.category = category
  }
  if (has('images')) {
    const images = Array.isArray(event.images)
      ? event.images.filter((item) => typeof item === 'string' && item)
      : []
    if (images.length === 0) return { code: -1, msg: '请至少保留 1 张商品图片' }
    data.images = images
  }
  if (has('status')) {
    data.status = Number(event.status) === 0 ? 0 : 1
  }

  if (Object.keys(data).length === 0) {
    return { code: -1, msg: '没有需要更新的字段' }
  }

  try {
    // ---- 权限校验：以数据库中的 role 为准 ----
    const userRes = await users.where({ openid: OPENID }).limit(1).get()
    const role = userRes.data[0] && userRes.data[0].role
    if (role !== 'seller') {
      return { code: -2, msg: '无权限操作，仅商家可修改商品' }
    }

    // ---- 确认商品存在 ----
    const productRes = await products.doc(productId).get().catch(() => null)
    if (!productRes || !productRes.data) {
      return { code: -1, msg: '商品不存在' }
    }

    await products.doc(productId).update({
      data: { ...data, updateTime: new Date() }
    })

    return { code: 0, msg: '商品已更新' }
  } catch (err) {
    console.error('[updateProduct] 更新商品失败', err)
    return { code: -1, msg: '更新失败，请稍后重试' }
  }
}
