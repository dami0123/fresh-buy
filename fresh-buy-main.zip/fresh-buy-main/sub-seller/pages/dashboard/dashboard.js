// sub-seller/pages/dashboard/dashboard.js —— 数据概览
//
// 订单统计改走 getSellerOrders 云函数（云函数内校验 seller 身份）取 total，
// 替代前端直查 orders 集合的写法——原写法任何买家都能读到全量订单的统计数，
// 属越权信息泄漏（CLAUDE.md「越权校验约定」）。商品总数属公开读数据，保留直查 count。
const { ORDER_STATUS } = require('../../../utils/constant')

const db = wx.cloud.database()

Page({
  data: {
    stats: {
      productTotal: 0,      // 商品总数
      orderTotal: 0,        // 订单总数
      pendingShipTotal: 0,  // 待发货订单数
      finishedTotal: 0      // 已完成订单数
    },
    loading: true,
    error: ''
  },

  onShow() {
    this.loadStats()
  },

  onPullDownRefresh() {
    this.loadStats(() => wx.stopPullDownRefresh())
  },

  /** 并发统计各维度数据 */
  loadStats(done) {
    this.setData({ loading: true, error: '' })

    // 订单统计：经 getSellerOrders 拿 total（status 0 表示不过滤 = 全部）
    const orderStats = (status) => new Promise((resolve) => {
      wx.cloud.callFunction({
        name: 'getSellerOrders',
        data: { status, page: 1, pageSize: 1 },
        success: (res) => {
          const result = res.result || {}
          if (result.code === 0) {
            resolve({ ok: true, total: result.total })
          } else if (result.code === -2) {
            resolve({ ok: false, denied: true })
          } else {
            resolve({ ok: false })
          }
        },
        fail: (err) => {
          console.error('[FreshBuy] 获取订单统计失败', err)
          resolve({ ok: false })
        }
      })
    })

    Promise.all([
      db.collection('products').count(),
      orderStats(0),
      orderStats(ORDER_STATUS.PENDING_SHIP),
      orderStats(ORDER_STATUS.FINISHED)
    ])
      .then(([productRes, allRes, pendingRes, finishedRes]) => {
        if (allRes.denied || pendingRes.denied || finishedRes.denied) {
          this.setData({ loading: false, error: '当前账号不是商家，无法查看订单数据' })
          return
        }

        this.setData({
          stats: {
            productTotal: productRes.total,
            orderTotal: allRes.ok ? allRes.total : 0,
            pendingShipTotal: pendingRes.ok ? pendingRes.total : 0,
            finishedTotal: finishedRes.ok ? finishedRes.total : 0
          },
          loading: false
        })
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取概览数据失败', err)
        this.setData({ loading: false, error: '数据加载失败，请检查数据库权限设置' })
      })
      .then(() => {
        if (typeof done === 'function') done()
      })
  },

  /** 快捷入口跳转 */
  onNavTap(e) {
    const { url } = e.currentTarget.dataset
    wx.navigateTo({ url })
  },

  /** 退出到身份选择页 */
  onLogout() {
    const app = getApp()
    app.globalData.role = ''
    app.globalData.userInfo = null
    wx.reLaunch({ url: '/pages/index/index' })
  }
})
