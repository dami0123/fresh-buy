// sub-seller/pages/ship/ship.js —— 发货拍照
// 职责：加载订单（收货地址 / 商品清单 / 驳回原因）-> 拍满 3 张发货照片 ->
//       逐张上传云存储（数据库只存 fileID）-> 调 shipOrder 云函数（1/2 -> 2）。
//   TODO(上线前必改)：开发期 sourceType 用 ['camera', 'album']，因为开发者工具模拟器
//   调不起相机；上线前必须改回 ['camera'] 强制拍照。见 CLAUDE.md「发货照片约定」。
const { toDate, formatAddress } = require('../../../utils/display')
const { formatTime, formatPrice } = require('../../../utils/format')

const MAX_PHOTO_COUNT = 3 // 发货照片固定 3 张

Page({
  data: {
    orderId: '',
    order: null,     // 订单信息（地址 / 商品清单 / 驳回原因）
    photos: [],      // 已选照片的本地临时路径，供页面预览
    submitting: false,
    error: ''
  },

  onLoad(options) {
    if (!options.id) {
      this.setData({ error: '缺少订单参数' })
      return
    }
    this.setData({ orderId: options.id })
    this.loadOrder()
  },

  /** 经 getSellerOrders 云函数加载订单（云函数内校验 seller 身份） */
  loadOrder() {
    wx.showLoading({ title: '加载中…', mask: true })

    wx.cloud.callFunction({
      name: 'getSellerOrders',
      data: { orderId: this.data.orderId },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          this.setData({ error: result.msg || '订单加载失败' })
          return
        }

        const order = result.order || {}
        this.setData({
          order: {
            ...order,
            createTimeText: formatTime(toDate(order.createTime)),
            totalPriceText: formatPrice(order.totalPrice),
            addressText: formatAddress(order.address),
            rejectText: order.shipRejectReason || ''
          }
        })
      },
      fail: (err) => {
        console.error('[FreshBuy] 加载订单失败', err)
        this.setData({ error: '网络异常，请稍后重试' })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },

  /** 拍照 / 选图：补足剩余张数 */
  onChoosePhoto() {
    if (this.data.submitting) return
    const remain = MAX_PHOTO_COUNT - this.data.photos.length
    if (remain <= 0) return

    wx.chooseMedia({
      count: remain,
      mediaType: ['image'],
      sourceType: ['camera', 'album'], // TODO(上线前必改)：改回 ['camera'] 强制拍照
      success: (res) => {
        const added = (res.tempFiles || []).map((file) => file.tempFilePath)
        const photos = this.data.photos.concat(added).slice(0, MAX_PHOTO_COUNT)
        this.setData({ photos })
        if (photos.length < MAX_PHOTO_COUNT) {
          wx.showToast({ title: `还需拍 ${MAX_PHOTO_COUNT - photos.length} 张`, icon: 'none' })
        }
      }
    })
  },

  /** 点击已拍照片可移除重拍 */
  onRemovePhoto(e) {
    if (this.data.submitting) return
    const index = Number(e.currentTarget.dataset.index)
    const photos = this.data.photos.slice()
    photos.splice(index, 1)
    this.setData({ photos })
  },

  /** 提交：逐张传云存储 -> shipOrder */
  onSubmit() {
    const { photos, orderId, submitting } = this.data
    if (submitting) return
    if (photos.length < MAX_PHOTO_COUNT) {
      wx.showToast({ title: `请拍满 ${MAX_PHOTO_COUNT} 张照片`, icon: 'none' })
      return
    }

    this.setData({ submitting: true })
    wx.showLoading({ title: '上传照片中…', mask: true })

    // 照片统一 wx.cloud.uploadFile 传云存储，数据库只存 fileID（CLAUDE.md「图片处理」）
    const uploadTasks = photos.map((path, index) => new Promise((resolve, reject) => {
      const match = /\.(\w+)$/.exec(path)
      const ext = match ? match[1] : 'jpg'
      const cloudPath = `ship/${orderId}/${Date.now()}-${index}-${Math.floor(Math.random() * 10000)}.${ext}`
      wx.cloud.uploadFile({
        cloudPath,
        filePath: path,
        success: (res) => resolve(res.fileID),
        fail: reject
      })
    }))

    Promise.all(uploadTasks)
      .then((fileIDs) => new Promise((resolve, reject) => {
        wx.cloud.callFunction({
          name: 'shipOrder',
          data: { orderId, photos: fileIDs },
          success: resolve,
          fail: reject
        })
      }))
      .then((res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '提交失败', icon: 'none' })
          return
        }
        wx.showToast({ title: '发货照片已提交', icon: 'success' })
        // 延迟返回，让用户看到成功提示；订单管理页 onShow 会刷新列表
        setTimeout(() => wx.navigateBack(), 1500)
      })
      .catch((err) => {
        console.error('[FreshBuy] 提交发货照片失败', err)
        wx.showToast({ title: '上传失败，请重试', icon: 'none' })
      })
      .then(() => {
        wx.hideLoading()
        this.setData({ submitting: false })
      })
  }
})
