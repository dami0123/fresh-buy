// sub-seller/pages/return-handle/return-handle.js —— 售后查看（只读）
//
// ⚠️ 责任判定由系统自动完成（aiJudge），商家只能查看结论，不能改判。
//    本页不出现任何判定 / 退款按钮，也不执行任何写操作。见 CLAUDE.md「售后判定约定」。
// 列表来自 getSellerOrders(filter='aftersale')：包含售后进行中（status 5）与
// 已终结（rejected 回退完成 / refund 已退款 / reship 已重发）的订单，
// 对应商家端流程图「处理退款申请 -> 查看退款结果 -> 查看结果」。
const { toDate, toDisplayUrls } = require('../../../utils/display')
const { formatTime, formatPrice } = require('../../../utils/format')
const { ORDER_STATUS_TEXT } = require('../../../utils/constant')

const PAGE_SIZE = 10

/** 售后处理结果文案（orders.return.resolution） */
const RESOLUTION_TEXT = {
  '': '待买家选择处理方式',
  rejected: '售后未通过（订单已回退完成）',
  refund: '已退款（订单已关闭）',
  reship: '已重发货（订单回到待发货）'
}

Page({
  data: {
    orders: [],
    page: 1,
    hasMore: true,
    loading: false,
    refreshing: false,
    error: ''
  },

  onLoad() {
    this.loadOrders(true)
  },

  onPullDownRefresh() {
    this.setData({ refreshing: true })
    this.loadOrders(true, () => {
      this.setData({ refreshing: false })
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadOrders(false)
    }
  },

  /** 分页加载售后订单 */
  loadOrders(reset, done) {
    const page = reset ? 1 : this.data.page + 1
    this.setData({ loading: true, error: '' })

    wx.cloud.callFunction({
      name: 'getSellerOrders',
      data: { filter: 'aftersale', page, pageSize: PAGE_SIZE },
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          this.setData({ loading: false, error: result.msg || '加载失败' })
          return
        }

        const list = (result.list || []).map((order) => this.decorate(order))
        const baseIndex = reset ? 0 : this.data.orders.length

        this.setData({
          orders: reset ? list : this.data.orders.concat(list),
          page,
          hasMore: !!result.hasMore,
          loading: false
        })

        // 退货照片是 fileID，逐单异步换临时链接
        list.forEach((order, i) => {
          const returnInfo = order.return || {}
          toDisplayUrls(returnInfo.photos || []).then((urls) => {
            this.setData({ [`orders[${baseIndex + i}].returnPhotos`]: urls })
          })
        })
      },
      fail: (err) => {
        console.error('[FreshBuy] 加载售后列表失败', err)
        this.setData({ loading: false, error: '网络异常，请稍后重试' })
      },
      complete: () => {
        if (typeof done === 'function') done()
      }
    })
  },

  /** 组装展示字段（只读展示，不改数据） */
  decorate(order) {
    const ret = order.return || {}
    const ai = ret.aiResult || {}

    return {
      ...order,
      createTimeText: formatTime(toDate(order.createTime)),
      totalPriceText: formatPrice(order.totalPrice),
      statusText: ORDER_STATUS_TEXT[order.status] || '未知',
      // 系统判定结论
      liableText: ret.liable === true ? '商家责任' : (ret.liable === false ? '非商家责任' : '待判定'),
      liableTheme: ret.liable === true ? 'danger' : 'safe',
      reason: ret.reason || '',
      confidenceText: typeof ret.confidence === 'number' ? Math.round(ret.confidence * 100) + '%' : '',
      // mock 规则输入摘要（二期真 AI 时 aiResult 结构变化，此处按字段容错取值）
      judgeDetailText: ai.input
        ? `退货照片 ${ai.input.returnPhotoCount} 张 · 发货照片 ${ai.input.shipPhotoCount} 张 · 收货后 ${ai.input.hoursSinceReceive} 小时`
        : '',
      resolutionText: RESOLUTION_TEXT[ret.resolution] || RESOLUTION_TEXT[''],
      applyAtText: formatTime(toDate(ret.applyAt)),
      refundAtText: ret.refundAt ? formatTime(toDate(ret.refundAt)) : '',
      returnPhotos: []
    }
  },

  /** 点击照片放大预览 */
  onPreviewPhoto(e) {
    const { urls, index } = e.currentTarget.dataset
    if (!Array.isArray(urls) || urls.length === 0) return
    wx.previewImage({ urls, current: urls[index] || urls[0] })
  }
})
