// sub-seller/pages/product-edit/product-edit.js —— 商品新增 / 编辑
//
// 职责：商品表单 + 图片上传（wx.cloud.uploadFile 传云存储，库中只存 fileID）。
// 提交调 createProduct（新增）/ updateProduct（编辑）云函数，
// 云函数内二次校验 role === 'seller' 与金额 / 库存（CLAUDE.md「商家端特别约定」）。
//
// 分类选项来自 utils/category.js，与买家首页静态分类、categories.key 严格对齐。
const { CATEGORIES } = require('../../../utils/category')
const { toDisplayUrls } = require('../../../utils/display')

const db = wx.cloud.database()
const MAX_IMAGE_COUNT = 5

Page({
  data: {
    productId: '',   // 有值 = 编辑模式
    categoryIndex: 0,
    categoryNames: CATEGORIES.map((item) => item.name),
    form: {
      name: '',
      price: '',
      stock: '',
      category: CATEGORIES[0].key,
      status: 1
    },
    images: [],      // [{ src, isLocal }]：src 为 fileID 或本地临时路径
    previewUrls: [], // 与 images 等长的可展示链接
    loading: false,
    saving: false,
    error: ''
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ productId: options.id })
      this.loadProduct(options.id)
    }
  },

  /** 编辑模式：读取商品填充表单（读操作可前端直查） */
  loadProduct(id) {
    this.setData({ loading: true, error: '' })

    db.collection('products').doc(id).get()
      .then((res) => {
        const p = res.data || {}
        const categoryIndex = Math.max(0, CATEGORIES.findIndex((item) => item.key === p.category))
        this.setData({
          categoryIndex,
          form: {
            name: p.name || '',
            price: p.price == null ? '' : String(p.price),
            stock: p.stock == null ? '' : String(p.stock),
            category: p.category || CATEGORIES[0].key,
            status: Number(p.status) === 0 ? 0 : 1
          },
          images: (p.images || []).filter(Boolean).map((src) => ({ src, isLocal: false })),
          loading: false
        })
        // fileID 换临时链接用于预览
        return toDisplayUrls((p.images || []).filter(Boolean))
      })
      .then((urls) => {
        if (Array.isArray(urls)) this.setData({ previewUrls: urls })
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取商品失败', err)
        this.setData({ loading: false, error: '商品加载失败' })
      })
  },

  /** 文本输入：价格 / 库存保持字符串，提交时统一转数字 */
  onInput(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ [`form.${key}`]: e.detail.value })
  },

  /** 分类选择 */
  onCategoryChange(e) {
    const index = Number(e.detail.value)
    this.setData({
      categoryIndex: index,
      'form.category': CATEGORIES[index].key
    })
  },

  /** 上架开关 */
  onStatusChange(e) {
    this.setData({ 'form.status': e.detail.value ? 1 : 0 })
  },

  /** 选图：补足剩余张数 */
  onChooseImage() {
    if (this.data.saving) return
    const remain = MAX_IMAGE_COUNT - this.data.images.length
    if (remain <= 0) return

    wx.chooseMedia({
      count: remain,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const added = (res.tempFiles || []).map((file) => ({ src: file.tempFilePath, isLocal: true }))
        this.setData({
          images: this.data.images.concat(added),
          previewUrls: this.data.previewUrls.concat(added.map((item) => item.src))
        })
      }
    })
  },

  /** 移除图片 */
  onRemoveImage(e) {
    if (this.data.saving) return
    const index = Number(e.currentTarget.dataset.index)
    const images = this.data.images.slice()
    const previewUrls = this.data.previewUrls.slice()
    images.splice(index, 1)
    previewUrls.splice(index, 1)
    this.setData({ images, previewUrls })
  },

  /** 提交：本地新图先传云存储 -> createProduct / updateProduct */
  onSubmit() {
    if (this.data.saving) return

    const { form, images, productId } = this.data
    const name = String(form.name || '').trim()
    const price = Number(form.price)
    const stock = Math.floor(Number(form.stock))

    // ---- 前端校验（云函数还会二次校验兜底）----
    if (!name) return wx.showToast({ title: '请填写商品名称', icon: 'none' })
    if (!Number.isFinite(price) || price <= 0) return wx.showToast({ title: '价格必须大于 0', icon: 'none' })
    if (!Number.isFinite(stock) || stock < 0) return wx.showToast({ title: '库存不能为负数', icon: 'none' })
    if (images.length === 0) return wx.showToast({ title: '请至少上传 1 张商品图片', icon: 'none' })

    this.setData({ saving: true })
    wx.showLoading({ title: '保存中…', mask: true })

    // 已有 fileID 直接复用；本地新图先传云存储
    const persisted = images.filter((item) => !item.isLocal).map((item) => item.src)
    const localImages = images.filter((item) => item.isLocal)

    const uploadTasks = localImages.map((item, index) => new Promise((resolve, reject) => {
      const match = /\.(\w+)$/.exec(item.src)
      const ext = match ? match[1] : 'jpg'
      const cloudPath = `products/${Date.now()}-${index}-${Math.floor(Math.random() * 10000)}.${ext}`
      wx.cloud.uploadFile({
        cloudPath,
        filePath: item.src,
        success: (res) => resolve(res.fileID),
        fail: reject
      })
    }))

    Promise.all(uploadTasks)
      .then((fileIDs) => new Promise((resolve, reject) => {
        const payload = {
          name,
          price,
          stock,
          category: form.category,
          status: form.status,
          images: persisted.concat(fileIDs)
        }
        // 编辑模式带 productId；新增 / 编辑分别走对应云函数
        const fnName = productId ? 'updateProduct' : 'createProduct'
        if (productId) payload.productId = productId

        wx.cloud.callFunction({
          name: fnName,
          data: payload,
          success: resolve,
          fail: reject
        })
      }))
      .then((res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '保存失败', icon: 'none' })
          return
        }
        wx.showToast({ title: '保存成功', icon: 'success' })
        setTimeout(() => wx.navigateBack(), 1200)
      })
      .catch((err) => {
        console.error('[FreshBuy] 保存商品失败', err)
        wx.showToast({ title: '保存失败，请重试', icon: 'none' })
      })
      .then(() => {
        wx.hideLoading()
        this.setData({ saving: false })
      })
  }
})
