// sub-seller/pages/order-manage/order-manage.js —— 订单发货处理
//
// 数据源：getSellerOrders 云函数（云函数内校验 seller 身份），替代前端直查全量订单
// —— 原写法任何买家都能读到所有订单，属安全缺陷（CLAUDE.md「越权校验约定」）。
//
// 发货：待发货订单跳 ship 页拍照发货；被驳回（状态 2 且含驳回原因）可重新拍照。
// 旧的 submitShip（调已废弃且已失效的 updateOrderStatus）已整体删除，
// 见 docs/团队任务分工.md「已知问题」。
const { toDate, formatAddress } = require('../../../utils/display')
const { formatTime, formatPrice } = require('../../../utils/format')
const { ORDER_STATUS, ORDER_STATUS_TEXT, ORDER_STATUS_THEME } = require('../../../utils/constant')

const PAGE_SIZE = 10

Page({
  data: {
    // 用 -1 表示「全部」：WXML 的 dataset 会把 null 转成空字符串，
    // 直接用 null 会退化成 where({ status: '' }) 而查不到数据
    tabs: [
      { status: -1, name: '全部' },
      { status: ORDER_STATUS.PENDING_SHIP, name: '待发货' },
      { status: ORDER_STATUS.PENDING_CONFIRM_SHIP, name: '待确认发货' },
      { status: ORDER_STATUS.DELIVERING, name: '配送中' },
      { status: ORDER_STATUS.FINISHED, name: '已完成' }
    ],
    activeStatus: -1, // -1 表示不过滤状态
    orders: [],
    page: 1,
    hasMore: true,
    loading: false,
    refreshing: false,
    error: ''
  },

  onLoad() {
    this.loadOrders(true)
  },

  // 从 ship 页返回时刷新当前 tab；首次进入由 onLoad 负责——
  // onShow 紧随 onLoad 触发，此时 _loaded 尚未置位，不会重复请求
  onShow() {
    if (this._loaded) this.loadOrders(true)
  },

  onPullDownRefresh() {
    this.setData({ refreshing: true })
    this.loadOrders(true, () => {
      this.setData({ refreshing: false })
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadOrders(false)
    }
  },

  /** 切换状态筛选 */
  onTabTap(e) {
    const status = e.currentTarget.dataset.status
    if (status === this.data.activeStatus) return
    this.setData({ activeStatus: status })
    this.loadOrders(true)
  },

  /**
   * 分页加载订单（经 getSellerOrders 云函数）
   * @param {boolean} reset true 表示重置到第一页
   */
  loadOrders(reset, done) {
    const page = reset ? 1 : this.data.page + 1
    const status = this.data.activeStatus
    this.setData({ loading: true, error: '' })

    const data = { page, pageSize: PAGE_SIZE }
    if (status !== -1) data.status = status

    wx.cloud.callFunction({
      name: 'getSellerOrders',
      data,
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          this.setData({ loading: false, error: result.msg || '加载失败' })
          return
        }

        const list = (result.list || []).map((order) => ({
          ...order,
          totalPriceText: formatPrice(order.totalPrice),
          createTimeText: formatTime(toDate(order.createTime)),
          statusText: ORDER_STATUS_TEXT[order.status] || '未知',
          statusTheme: ORDER_STATUS_THEME[order.status] || 'done',
          count: (order.items || []).reduce((sum, i) => sum + Number(i.count || 0), 0),
          addressText: formatAddress(order.address),
          // 状态 1 可拍照发货；状态 2 且被买家驳回（含驳回原因）才提供重新拍照入口
          canShip: order.status === ORDER_STATUS.PENDING_SHIP,
          canReshoot: order.status === ORDER_STATUS.PENDING_CONFIRM_SHIP && !!order.shipRejectReason,
          rejectText: order.shipRejectReason || '',
          isReship: Number(order.reshipCount) > 0
        }))

        this.setData({
          orders: reset ? list : this.data.orders.concat(list),
          page,
          hasMore: !!result.hasMore,
          loading: false
        })
        this._loaded = true
      },
      fail: (err) => {
        console.error('[FreshBuy] 读取订单列表失败', err)
        this.setData({ loading: false, error: '网络异常，请稍后重试' })
      },
      complete: () => {
        if (typeof done === 'function') done()
      }
    })
  },

  /** 拍照发货 / 重新拍照：统一跳 ship 页 */
  onShip(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({ url: `/sub-seller/pages/ship/ship?id=${id}` })
  }
})
