// sub-seller/pages/product-manage/product-manage.js —— 商品上下架与库存
//
// 列表按 CLAUDE.md「商家端特别约定」使用 skip / limit 分页；products 属公开读数据，
// 读操作允许前端直查。上下架 / 库存修改属写操作，一律走 updateProduct 云函数
// （云函数内二次校验 role === 'seller' 与金额 / 库存，防止越权篡改）。
const { toDisplayUrls } = require('../../../utils/display')
const { formatPrice } = require('../../../utils/format')

const db = wx.cloud.database()
const PAGE_SIZE = 10

Page({
  data: {
    products: [],
    page: 1,
    hasMore: true,
    loading: false,
    refreshing: false,
    updating: false,
    error: ''
  },

  onLoad() {
    this.loadProducts(true)
  },

  // 从编辑页返回时刷新；首次进入由 onLoad 负责（onShow 紧随 onLoad 触发，
  // 此时 _loaded 尚未置位，不会重复请求）
  onShow() {
    if (this._loaded) this.loadProducts(true)
  },

  onPullDownRefresh() {
    this.setData({ refreshing: true })
    this.loadProducts(true, () => {
      this.setData({ refreshing: false })
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadProducts(false)
    }
  },

  /** 分页加载商品；reset 为 true 时回到第一页 */
  loadProducts(reset, done) {
    const page = reset ? 1 : this.data.page + 1
    this.setData({ loading: true, error: '' })

    db.collection('products')
      .orderBy('createTime', 'desc')
      .skip((page - 1) * PAGE_SIZE)
      .limit(PAGE_SIZE)
      .get()
      .then((res) => {
        const list = (res.data || []).map((item) => ({
          ...item,
          priceText: formatPrice(item.price),
          // 列表里只取首图作为封面，避免 WXML 中直接下标访问 undefined
          cover: (item.images && item.images[0]) || '',
          onSale: Number(item.status) === 1
        }))
        const baseIndex = reset ? 0 : this.data.products.length

        this.setData({
          products: reset ? list : this.data.products.concat(list),
          page,
          // 返回条数不足一页即认为没有更多数据
          hasMore: list.length === PAGE_SIZE,
          loading: false
        })
        this._loaded = true

        // 封面是 fileID 时换临时链接（网络直链原样返回）
        toDisplayUrls(list.map((item) => item.cover)).then((urls) => {
          urls.forEach((url, i) => {
            this.setData({ [`products[${baseIndex + i}].cover`]: url })
          })
        })
      })
      .catch((err) => {
        console.error('[FreshBuy] 读取商品列表失败', err)
        this.setData({ loading: false, error: '加载失败，请检查数据库权限设置' })
      })
      .then(() => {
        if (typeof done === 'function') done()
      })
  },

  /** 上架 / 下架（写操作经 updateProduct 云函数二次校验） */
  onToggleSale(e) {
    if (this.data.updating) return
    const { id } = e.currentTarget.dataset
    const product = this.data.products.find((item) => item._id === id)
    if (!product) return

    const targetStatus = product.onSale ? 0 : 1
    this.callUpdateProduct(
      { productId: id, status: targetStatus },
      targetStatus === 1 ? '已上架' : '已下架'
    )
  },

  /** 修改库存：弹窗输入，云函数二次校验 */
  onEditStock(e) {
    if (this.data.updating) return
    const { id } = e.currentTarget.dataset
    const product = this.data.products.find((item) => item._id === id)
    if (!product) return

    wx.showModal({
      title: `修改库存（当前 ${product.stock}）`,
      editable: true,
      placeholderText: '请输入新库存',
      success: (res) => {
        if (!res.confirm) return
        const value = String(res.content || '').trim()
        const stock = Math.floor(Number(value))
        if (value === '' || !Number.isFinite(stock) || stock < 0) {
          wx.showToast({ title: '库存必须是不小于 0 的整数', icon: 'none' })
          return
        }
        this.callUpdateProduct({ productId: id, stock }, '库存已更新')
      }
    })
  },

  /** 编辑商品：跳商品编辑页 */
  onEdit(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({ url: `/sub-seller/pages/product-edit/product-edit?id=${id}` })
  },

  /** 新增商品 */
  onCreate() {
    wx.navigateTo({ url: '/sub-seller/pages/product-edit/product-edit' })
  },

  /** 统一的 updateProduct 调用封装 */
  callUpdateProduct(data, okText) {
    this.setData({ updating: true })
    wx.showLoading({ title: '处理中…', mask: true })

    wx.cloud.callFunction({
      name: 'updateProduct',
      data,
      success: (res) => {
        const result = res.result || {}
        if (result.code !== 0) {
          wx.showToast({ title: result.msg || '操作失败', icon: 'none' })
          return
        }
        wx.showToast({ title: okText || '操作成功', icon: 'success' })
        this.loadProducts(true)
      },
      fail: (err) => {
        console.error('[FreshBuy] 更新商品失败', err)
        wx.showToast({ title: '网络异常，请稍后重试', icon: 'none' })
      },
      complete: () => {
        wx.hideLoading()
        this.setData({ updating: false })
      }
    })
  }
})
